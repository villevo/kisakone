<?php /* Smarty version 2.6.28, created on 2016-05-20 22:52:46
         compiled from include/pdgainfotable.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'translate', 'include/pdgainfotable.tpl', 28, false),array('modifier', 'lower', 'include/pdgainfotable.tpl', 57, false),)), $this); ?>
<?php $this->_cache_serials['./Smarty/templates_c\%%57^57F^57FB2402%%pdgainfotable.tpl.inc'] = '90b2c64254d05ecf8fcf0d344999512b'; ?>
<?php if ($this->_tpl_vars['pdga']): ?>
<?php $this->assign('country', $this->_tpl_vars['pdga_country']); ?>
<?php if (! $this->_tpl_vars['country']): ?><?php $this->assign('country', 'FI'); ?><?php endif; ?>
<tr>
    <td><label for="pdga_number"><?php if ($this->caching && !$this->_cache_including): echo '{nocache:90b2c64254d05ecf8fcf0d344999512b#0}'; endif;echo translate_smarty(array('id' => 'pdga_number'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:90b2c64254d05ecf8fcf0d344999512b#0}'; endif;?>
</label></td>
    <td><span id="pdga_number"><a href="http://www.pdga.com/player/<?php echo $this->_tpl_vars['player']->pdga; ?>
"><?php echo $this->_tpl_vars['pdga']; ?>
</a></span></td>
</tr>
<tr>
    <td><label for="pdga_membership_status"><?php if ($this->caching && !$this->_cache_including): echo '{nocache:90b2c64254d05ecf8fcf0d344999512b#1}'; endif;echo translate_smarty(array('id' => 'pdga_membership'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:90b2c64254d05ecf8fcf0d344999512b#1}'; endif;?>
</label></td>
    <td><span id="pdga_membership_status"><?php if ($this->caching && !$this->_cache_including): echo '{nocache:90b2c64254d05ecf8fcf0d344999512b#2}'; endif;echo translate_smarty(array('id' => "pdga_membership_".($this->_tpl_vars['pdga_membership_status'])), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:90b2c64254d05ecf8fcf0d344999512b#2}'; endif;?>
</span></td>
</tr>
<tr>
    <td><label for="pdga_official_status"><?php if ($this->caching && !$this->_cache_including): echo '{nocache:90b2c64254d05ecf8fcf0d344999512b#3}'; endif;echo translate_smarty(array('id' => 'pdga_official'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:90b2c64254d05ecf8fcf0d344999512b#3}'; endif;?>
</label></td>
    <td><span id="pdga_official_status"><?php if ($this->caching && !$this->_cache_including): echo '{nocache:90b2c64254d05ecf8fcf0d344999512b#4}'; endif;echo translate_smarty(array('id' => "pdga_official_".($this->_tpl_vars['pdga_official_status'])), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:90b2c64254d05ecf8fcf0d344999512b#4}'; endif;?>
</span></td>
</tr>
<tr>
    <td><label for="pdga_rating"><?php if ($this->caching && !$this->_cache_including): echo '{nocache:90b2c64254d05ecf8fcf0d344999512b#5}'; endif;echo translate_smarty(array('id' => 'pdga_rating'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:90b2c64254d05ecf8fcf0d344999512b#5}'; endif;?>
</label></td>
    <td><span id="pdga_rating"><?php echo $this->_tpl_vars['pdga_rating']; ?>
</span></td>
</tr>
<tr>
    <td><label for="pdga_status"><?php if ($this->caching && !$this->_cache_including): echo '{nocache:90b2c64254d05ecf8fcf0d344999512b#6}'; endif;echo translate_smarty(array('id' => 'pdga_status'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:90b2c64254d05ecf8fcf0d344999512b#6}'; endif;?>
</label></td>
    <td><span id="pdga_status"><?php if ($this->caching && !$this->_cache_including): echo '{nocache:90b2c64254d05ecf8fcf0d344999512b#7}'; endif;echo translate_smarty(array('id' => "pdga_status_".($this->_tpl_vars['pdga_classification'])), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:90b2c64254d05ecf8fcf0d344999512b#7}'; endif;?>
</span></td>
</tr>
<tr>
    <td><label for="pdga_birth_year"><?php if ($this->caching && !$this->_cache_including): echo '{nocache:90b2c64254d05ecf8fcf0d344999512b#8}'; endif;echo translate_smarty(array('id' => 'user_yearofbirth'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:90b2c64254d05ecf8fcf0d344999512b#8}'; endif;?>
</label></td>
    <td><span id="pdga_birth_year"><?php echo $this->_tpl_vars['pdga_birth_year']; ?>
</span></td>
</tr>
<tr>
    <td><label for="pdga_gender"><?php if ($this->caching && !$this->_cache_including): echo '{nocache:90b2c64254d05ecf8fcf0d344999512b#9}'; endif;echo translate_smarty(array('id' => 'user_gender'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:90b2c64254d05ecf8fcf0d344999512b#9}'; endif;?>
</label></td>
    <td><span id="pdga_gender"><?php if ($this->caching && !$this->_cache_including): echo '{nocache:90b2c64254d05ecf8fcf0d344999512b#10}'; endif;echo translate_smarty(array('id' => "pdga_gender_".($this->_tpl_vars['pdga_gender'])), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:90b2c64254d05ecf8fcf0d344999512b#10}'; endif;?>
</span></td>
</tr>
<tr>
    <td><label for="pdga_country"><?php if ($this->caching && !$this->_cache_including): echo '{nocache:90b2c64254d05ecf8fcf0d344999512b#11}'; endif;echo translate_smarty(array('id' => 'pdga_country'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:90b2c64254d05ecf8fcf0d344999512b#11}'; endif;?>
</label></td>
    <td><span name="pdga_country"><span class="flag-icon flag-icon-<?php echo ((is_array($_tmp=$this->_tpl_vars['country'])) ? $this->_run_mod_handler('lower', true, $_tmp) : smarty_modifier_lower($_tmp)); ?>
"></span><?php if ($this->_tpl_vars['pdga_state']): ?><?php echo $this->_tpl_vars['pdga_state']; ?>
, <?php endif; ?><?php echo $this->_tpl_vars['pdga_country']; ?>
</span></td>
</tr>
<?php endif; ?>