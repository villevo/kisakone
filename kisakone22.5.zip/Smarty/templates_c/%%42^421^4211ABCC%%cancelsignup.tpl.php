<?php /* Smarty version 2.6.28, created on 2016-05-20 23:34:36
         compiled from eventviews/cancelsignup.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'translate', 'eventviews/cancelsignup.tpl', 30, false),)), $this); ?>
<?php $this->_cache_serials['./Smarty/templates_c\%%42^421^4211ABCC%%cancelsignup.tpl.inc'] = 'b494efd3b1eaf047729b54f1406b6d31'; ?> <?php if ($this->_tpl_vars['mode'] == 'body'): ?>

 <div id="event_content">
    <?php echo $this->_tpl_vars['page']->formattedText; ?>

</div>

<?php if (! $this->_tpl_vars['user']): ?>
    <p class="error"><?php if ($this->caching && !$this->_cache_including): echo '{nocache:b494efd3b1eaf047729b54f1406b6d31#0}'; endif;echo translate_smarty(array('id' => 'login_to_sign_up'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:b494efd3b1eaf047729b54f1406b6d31#0}'; endif;?>
</p>
<?php elseif (! $this->_tpl_vars['signupOpen']): ?>
    <p><?php if ($this->caching && !$this->_cache_including): echo '{nocache:b494efd3b1eaf047729b54f1406b6d31#1}'; endif;echo translate_smarty(array('id' => 'cant_cancel_signup_now'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:b494efd3b1eaf047729b54f1406b6d31#1}'; endif;?>
</p>
<?php else: ?>

    <?php if ($this->_tpl_vars['queued']): ?>
    <p class="signup_status"><?php if ($this->caching && !$this->_cache_including): echo '{nocache:b494efd3b1eaf047729b54f1406b6d31#2}'; endif;echo translate_smarty(array('id' => 'signed_up_in_queue'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:b494efd3b1eaf047729b54f1406b6d31#2}'; endif;?>
</p>
    <?php elseif ($this->_tpl_vars['payment_enabled']): ?>
        <?php if ($this->_tpl_vars['paid']): ?>
        <p class="signup_status"><?php if ($this->caching && !$this->_cache_including): echo '{nocache:b494efd3b1eaf047729b54f1406b6d31#3}'; endif;echo translate_smarty(array('id' => 'signed_up_and_paid'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:b494efd3b1eaf047729b54f1406b6d31#3}'; endif;?>
</p>
        <?php else: ?>
        <p class="signup_status"><?php if ($this->caching && !$this->_cache_including): echo '{nocache:b494efd3b1eaf047729b54f1406b6d31#4}'; endif;echo translate_smarty(array('id' => 'signed_up_not_paid'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:b494efd3b1eaf047729b54f1406b6d31#4}'; endif;?>
</p>
        <?php endif; ?>
    <?php else: ?>
        <p class="signup_status"><?php if ($this->caching && !$this->_cache_including): echo '{nocache:b494efd3b1eaf047729b54f1406b6d31#5}'; endif;echo translate_smarty(array('id' => 'signed_up_payment_disabled'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:b494efd3b1eaf047729b54f1406b6d31#5}'; endif;?>
</p>
    <?php endif; ?>

    <form method="post">
        <input type="hidden" name="formid" value="cancel_signup" />
        <input type="submit" value="<?php if ($this->caching && !$this->_cache_including): echo '{nocache:b494efd3b1eaf047729b54f1406b6d31#6}'; endif;echo translate_smarty(array('id' => 'cancelsignup'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:b494efd3b1eaf047729b54f1406b6d31#6}'; endif;?>
" />
    </form>
<?php endif; ?>

<?php endif; ?>