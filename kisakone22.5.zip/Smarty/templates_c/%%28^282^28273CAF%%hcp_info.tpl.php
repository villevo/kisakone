<?php /* Smarty version 2.6.28, created on 2016-05-22 01:25:52
         compiled from include/hcp_info.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('modifier', 'escape', 'include/hcp_info.tpl', 5, false),array('modifier', 'date_format', 'include/hcp_info.tpl', 26, false),array('function', 'url', 'include/hcp_info.tpl', 29, false),array('function', 'translate', 'include/hcp_info.tpl', 37, false),)), $this); ?>
<?php $this->_cache_serials['./Smarty/templates_c\%%28^282^28273CAF%%hcp_info.tpl.inc'] = 'a05b36d2a132d400ae376e8cd8734fe1'; ?>


<br><br>
<h3>Pelaajan <?php echo ((is_array($_tmp=$this->_tpl_vars['userinfo']->fullname)) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
 tasoituskierrokset</h3>
<table border="0" style="border-spacing:0px">
	<!--<tr>
	<td colspan=7></td>
		<td colspan=3 class="table_hcp_events_hcp">HCP</td>
	</tr>-->
    <tr class="border_bottom">
		<th>Päivämäärä</th>
		<th class="nowrap">Kilpailun nimi</th>
        <th>Rata</th>
		<th class="nowrap">Pelattu luokassa</th>
		<th>Tulos (+/-)</th>
		<th>Sijoutus</th>
		<th width=30px></th>
		<th class="nowrap">Kierroksella käytetty tasoitus(Tarkka)</th>       
		<th class="">Kierrokselta tuleva tasoitus</th>
		<th class="nowrap ">Radan Rating/slope</th>

    </tr>
   <?php $_from = $this->_tpl_vars['events']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['event']):
?>
        <tr>
		            <td style="padding-bottom: 5px;"><?php echo ((is_array($_tmp=$this->_tpl_vars['event']->roundtime)) ? $this->_run_mod_handler('date_format', true, $_tmp, "%e.%m.%Y") : smarty_modifier_date_format($_tmp, "%e.%m.%Y")); ?>
</td>

            </td>
            <td> <span class="nowrap"><a href="<?php if ($this->caching && !$this->_cache_including): echo '{nocache:a05b36d2a132d400ae376e8cd8734fe1#0}'; endif;echo url_smarty(array('page' => 'event','id' => $this->_tpl_vars['event']->eid), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:a05b36d2a132d400ae376e8cd8734fe1#0}'; endif;?>
"><?php echo ((is_array($_tmp=$this->_tpl_vars['event']->eventname)) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>

               </span>
				</td>
            <td class="nowrap"><?php echo ((is_array($_tmp=$this->_tpl_vars['event']->coursename)) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
</td>
            <td style="text-align: center;"><?php echo ((is_array($_tmp=$this->_tpl_vars['event']->playedclass)) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
</td>
            <td class="nowrap" style="text-align: center;"><?php echo ((is_array($_tmp=$this->_tpl_vars['event']->score)) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
 (<?php if ($this->_tpl_vars['event']->scoreplusminus > 0): ?>+<?php endif; ?><?php echo ((is_array($_tmp=$this->_tpl_vars['event']->scoreplusminus)) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
)</td>
			
			<td><a href="<?php if ($this->caching && !$this->_cache_including): echo '{nocache:a05b36d2a132d400ae376e8cd8734fe1#1}'; endif;echo url_smarty(array('page' => 'event','view' => 'leaderboard','id' => $this->_tpl_vars['event']->eid), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:a05b36d2a132d400ae376e8cd8734fe1#1}'; endif;?>
">
                    <img src="<?php echo $this->_tpl_vars['url_base']; ?>
images/trophyIcon.png" alt="<?php if ($this->caching && !$this->_cache_including): echo '{nocache:a05b36d2a132d400ae376e8cd8734fe1#2}'; endif;echo translate_smarty(array('id' => 'results_available'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:a05b36d2a132d400ae376e8cd8734fe1#2}'; endif;?>
" title="<?php if ($this->caching && !$this->_cache_including): echo '{nocache:a05b36d2a132d400ae376e8cd8734fe1#3}'; endif;echo translate_smarty(array('id' => 'results_available'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:a05b36d2a132d400ae376e8cd8734fe1#3}'; endif;?>
"/>  <?php echo $this->_tpl_vars['event']->standing; ?>
. sija</a>
			</td>
			<td></td>			
			<td class="nowrap table_hcp_events_hcp"><?php if ($this->_tpl_vars['event']->hcp_used > 0): ?>+<?php endif; ?><?php echo ((is_array($_tmp=$this->_tpl_vars['event']->rounded_hcp_used)) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
 (<?php if ($this->_tpl_vars['event']->hcp_used > 0): ?>+<?php endif; ?><?php echo ((is_array($_tmp=$this->_tpl_vars['event']->hcp_used)) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
)</td>
			
			<td class="nowrap table_hcp_events_hcp"><abbr class="player_abbr"title="Laskettu kaavalla: (<?php echo ((is_array($_tmp=$this->_tpl_vars['event']->score)) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
 - <?php echo ((is_array($_tmp=$this->_tpl_vars['event']->courserating)) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
) * (80 / <?php echo ((is_array($_tmp=$this->_tpl_vars['event']->courseslope)) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
)"><?php if ($this->_tpl_vars['event']->round_hcp > 0): ?>+<?php endif; ?><?php echo ((is_array($_tmp=$this->_tpl_vars['event']->round_hcp)) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
</abbr></td>									
	
			<td class="nowrap table_hcp_events_hcp"><?php echo ((is_array($_tmp=$this->_tpl_vars['event']->courserating)) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
 / <?php echo ((is_array($_tmp=$this->_tpl_vars['event']->courseslope)) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
</td>			
		


        </tr>
        <?php endforeach; else: ?>
        <tr><td colspan="4">
            <p>Pelaajalla ei ole pelattuna tasoituksellisia kilpailuja.</p>
        </td></tr>
    <?php endif; unset($_from); ?>
</table>
<h2> Tasoituksen määräytyminen</h2>
<table>
<tr>
<td>
<h4>Pelaajan tasoitus</h4>
	<ul>
		Pelaajantasoitus muodostuu kierroksilta tulevista <i>kierrostasoituksista.</i><br>
		<br><span style="background: lightgray; padding: 5px; border-radius: 5px;">Pelaajantasoitus = Parhaiden kierrostasoitusten keskiarvo  x 0,96</span><br><br>
		Laskennassa käytetään pelaajan 1-10 parasta kierrostasoitusta riippuen pelattujen kierrosten määrästä(taulukko oikealla)
		<br>
		Tasoitusjärjestelmän suurin tasoitus on 26, eli tätä isompaa pelaajatasoitusta järjestelmä ei anna.
		<br>
		<br>
		Tasoituksellisessa kisassa tasoituskisan tulokset: Tasoitustulos = heitetty tulos - pelaajantasoitus.
		<br>
		Tasoituksellisten kilpailujen Leaderboard sivulla alimmaisena on tasoituskisan tulokset. Tasatuloksissa voittaa suuremman tasoituksen omaava pelaaja. 
	</ul>
<h4>Kierrostasoituksen määräytyminen</h4>

	<ul>
	Tasoitusjärjestelmän keskeisenä osana on radalle asetettavat tasoitus-arvot joiden avulla tasoitusjärjestelmän käyttö eri radoilla on mahdollista. 
	<br>
	Toistaiseksi vain Toramo ja Patokoski on asetettu tasoituksellisiksi radoiksi.
	<br>
	<br><span style="background: lightgray; padding: 5px; border-radius: 5px;">Kaava kierrostasoituksen laskennassa =(Tulos - Rating) * (80 / Slope ) </span><br>
	<br><br>
	Rataa koskevia arvoja on kaksi, Rating ja Slope:
	<br>
	<li><b>Rating</b> = luku joka kuvaa radan vaikeutta ja luku on se tulos millä radalta saa tasoituskierroksen 0. Rating luku on olennaisin muuttuja kaavassa.
	<br>Toramon osalta tämä luku on 67 eli sama kuin radan par.
	<br>Patokoski x2:n osalta tämä luku on 48 eli sama kuin 6 alle par.
	toisin sanoen toramolla tulos Par on yhtä hyvä kuin patokoskella tulos -6 (kahdelta kierrokselta).
	</li>
	<br>
	<li><b>Slope</b> = luku joka kuvaa radan vaikeutta tai siis antaa kerrointa lisää/vähemmän kun heitetty tulos eroaa Ratingista. Joillakin radoilla plussaa tulee helpommin kuin toisilla(Puistorata vs metsärata, pitkät väylät vs. lyhyet väylät tai tiheät metsät vs harvat metsät.)
	Perusarvo on 80, joka on toramon Slope arvo.
	Patokosken slope on 70.
	<br>
	Patokoski on helppo rata jolla ei tule helposti isoja lukemia joten jos heität +10 patokoskella niin eikö se ole tosi huonosti? slope arvolla saadan kaavan kautta kerrointa 80/70 = 1.14 jolloin tasoituskierrokseksi tuloksella +10 patokoskella tulee (64 - 48) * (80 / 70) =  18,2
	<br>	
	<br>
	Muutama esimerkki radoilta tulevista tasoituksista:
	<table border="1" cellpadding="0" cellspacing="0" style="width: 200px; text-align: center;">
		<tr>
			<th></th>
			<th colspan=2 style="white-space: nowrap;">Radalta tuleva tasoitus</th>
		</tr>
		<tr>
			<th>tulos</th>
			<th>Toramo</th>
			<th style="white-space: nowrap;" >Patokoski x2</th>
		</tr>

		<tr>
			<td>-6</td>
			<td>-6</td>
			<td>0</td>
		</tr>
		<tr>
			<td>par</td>
			<td>0</td>
			<td>6,8</td>
		</tr>
		<tr>
			<td>5</td>
			<td>5</td>
			<td>12,5</td>
		</tr>
		<tr>
			<td>10</td>
			<td>10</td>
			<td>18,2</td>
		</tr>
		<tr>
			<td>20</td>
			<td>20</td>
			<td>29,7</td>
		</tr>
</table>
</ul>


</td>
<td style="width: 300px;">
	<table border="1" cellpadding="0" cellspacing="0" style="width: 200px; border-style: hidden;     text-align: center;">
		<tr>
			<th>Tasoituskierroksia</th>
			<th>Käytettävien kierrosten määrä</th>
		</tr>
		<tr>
			<td>1-3</td>
			<td>1</td>
		</tr>
		<tr>
			<td>4-6</td>
			<td>2</td>
		</tr>
		<tr>
			<td>7-8</td>
			<td>3</td>
		</tr>
		<tr>
			<td>9-10</td>
			<td>4</td>
		</tr>
		<tr>
			<td>11-12</td>
			<td>5</td>
		</tr>
		<tr>
			<td>13-14</td>
			<td>6</td>
		</tr>
		<tr>
			<td>15-16</td>
			<td>7</td>
		</tr>
		<tr>
			<td>17</td>
			<td>8</td>
		</tr>
		<tr>
			<td>18</td>
			<td>9</td>
		</tr>
		<tr>
			<td>19 ja yli</td>
			<td>10</td>
		</tr>
	</table>
</td>
</tr>
</table>


<script type="text/javascript">
//<![CDATA[
<?php echo '
$(document).ready(function(){
    $($(".SortHeading").get(0)).click();
});

'; ?>

//]]>
</script>