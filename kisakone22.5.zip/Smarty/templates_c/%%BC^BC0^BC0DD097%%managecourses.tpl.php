<?php /* Smarty version 2.6.28, created on 2016-05-21 02:46:36
         compiled from managecourses.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'translate', 'managecourses.tpl', 22, false),array('function', 'url', 'managecourses.tpl', 26, false),array('modifier', 'escape', 'managecourses.tpl', 39, false),)), $this); ?>
<?php $this->_cache_serials['./Smarty/templates_c\%%BC^BC0^BC0DD097%%managecourses.tpl.inc'] = '4a84f8d70399c802c7b378146d318645'; ?><?php if ($this->caching && !$this->_cache_including): echo '{nocache:4a84f8d70399c802c7b378146d318645#0}'; endif;echo translate_smarty(array('assign' => 'title','id' => 'managecourses_title'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:4a84f8d70399c802c7b378146d318645#0}'; endif;?>

<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'include/header.tpl', 'smarty_include_vars' => array('title' => $this->_tpl_vars['title'])));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>

<?php if ($_GET['id']): ?>
<p><a href="<?php if ($this->caching && !$this->_cache_including): echo '{nocache:4a84f8d70399c802c7b378146d318645#1}'; endif;echo url_smarty(array('page' => 'editcourse','id' => 'new','event' => $_GET['id']), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:4a84f8d70399c802c7b378146d318645#1}'; endif;?>
"><?php if ($this->caching && !$this->_cache_including): echo '{nocache:4a84f8d70399c802c7b378146d318645#2}'; endif;echo translate_smarty(array('id' => 'new_course'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:4a84f8d70399c802c7b378146d318645#2}'; endif;?>
</a></p>
<?php else: ?>
<p><a href="<?php if ($this->caching && !$this->_cache_including): echo '{nocache:4a84f8d70399c802c7b378146d318645#3}'; endif;echo url_smarty(array('page' => 'editcourse','id' => 'new'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:4a84f8d70399c802c7b378146d318645#3}'; endif;?>
"><?php if ($this->caching && !$this->_cache_including): echo '{nocache:4a84f8d70399c802c7b378146d318645#4}'; endif;echo translate_smarty(array('id' => 'new_course'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:4a84f8d70399c802c7b378146d318645#4}'; endif;?>
</a></p>
<?php endif; ?>

<table class="oddrows narrow">
    <tr>
        <th><?php if ($this->caching && !$this->_cache_including): echo '{nocache:4a84f8d70399c802c7b378146d318645#5}'; endif;echo translate_smarty(array('id' => 'name'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:4a84f8d70399c802c7b378146d318645#5}'; endif;?>
</th>
        <th><?php if ($this->caching && !$this->_cache_including): echo '{nocache:4a84f8d70399c802c7b378146d318645#6}'; endif;echo translate_smarty(array('id' => 'edit'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:4a84f8d70399c802c7b378146d318645#6}'; endif;?>
</th>
        <th><?php if ($this->caching && !$this->_cache_including): echo '{nocache:4a84f8d70399c802c7b378146d318645#7}'; endif;echo translate_smarty(array('id' => 'copy'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:4a84f8d70399c802c7b378146d318645#7}'; endif;?>
</th>
    </tr>
<?php $_from = $this->_tpl_vars['courses']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['course']):
?>
    <tr>
        <td><?php echo ((is_array($_tmp=$this->_tpl_vars['course']['Name'])) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
</td>

        <td>
            <?php if ($_GET['id'] && ! $this->_tpl_vars['admin']): ?>
                <?php if ($this->_tpl_vars['course']['Event'] == $_GET['id']): ?>
                 <a href="<?php if ($this->caching && !$this->_cache_including): echo '{nocache:4a84f8d70399c802c7b378146d318645#8}'; endif;echo url_smarty(array('page' => 'editcourse','id' => $this->_tpl_vars['course']['id'],'event' => $_GET['id']), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:4a84f8d70399c802c7b378146d318645#8}'; endif;?>
"><?php if ($this->caching && !$this->_cache_including): echo '{nocache:4a84f8d70399c802c7b378146d318645#9}'; endif;echo translate_smarty(array('id' => 'edit'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:4a84f8d70399c802c7b378146d318645#9}'; endif;?>
</a>
                <?php else: ?>
                    <?php if ($this->caching && !$this->_cache_including): echo '{nocache:4a84f8d70399c802c7b378146d318645#10}'; endif;echo translate_smarty(array('id' => 'edit_blocked'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:4a84f8d70399c802c7b378146d318645#10}'; endif;?>

                <?php endif; ?>
            <?php else: ?>
                <a href="<?php if ($this->caching && !$this->_cache_including): echo '{nocache:4a84f8d70399c802c7b378146d318645#11}'; endif;echo url_smarty(array('page' => 'editcourse','id' => $this->_tpl_vars['course']['id']), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:4a84f8d70399c802c7b378146d318645#11}'; endif;?>
"><?php if ($this->caching && !$this->_cache_including): echo '{nocache:4a84f8d70399c802c7b378146d318645#12}'; endif;echo translate_smarty(array('id' => 'edit'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:4a84f8d70399c802c7b378146d318645#12}'; endif;?>
</a>
            <?php endif; ?>
        </td>
        <td>
            <?php if ($_GET['id']): ?>
                <a href="<?php if ($this->caching && !$this->_cache_including): echo '{nocache:4a84f8d70399c802c7b378146d318645#13}'; endif;echo url_smarty(array('page' => 'editcourse','id' => 'new','template' => $this->_tpl_vars['course']['id'],'event' => $_GET['id']), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:4a84f8d70399c802c7b378146d318645#13}'; endif;?>
"><?php if ($this->caching && !$this->_cache_including): echo '{nocache:4a84f8d70399c802c7b378146d318645#14}'; endif;echo translate_smarty(array('id' => 'copy'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:4a84f8d70399c802c7b378146d318645#14}'; endif;?>
</a>
            <?php else: ?>
                <a href="<?php if ($this->caching && !$this->_cache_including): echo '{nocache:4a84f8d70399c802c7b378146d318645#15}'; endif;echo url_smarty(array('page' => 'editcourse','id' => 'new','template' => $this->_tpl_vars['course']['id']), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:4a84f8d70399c802c7b378146d318645#15}'; endif;?>
"><?php if ($this->caching && !$this->_cache_including): echo '{nocache:4a84f8d70399c802c7b378146d318645#16}'; endif;echo translate_smarty(array('id' => 'copy'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:4a84f8d70399c802c7b378146d318645#16}'; endif;?>
</a>
            <?php endif; ?>
        </td>
    </tr>
<?php endforeach; endif; unset($_from); ?>
</table>

<?php if ($_GET['id']): ?>
<p><a href="<?php if ($this->caching && !$this->_cache_including): echo '{nocache:4a84f8d70399c802c7b378146d318645#17}'; endif;echo url_smarty(array('page' => 'editcourse','id' => 'new','event' => $_GET['id']), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:4a84f8d70399c802c7b378146d318645#17}'; endif;?>
"><?php if ($this->caching && !$this->_cache_including): echo '{nocache:4a84f8d70399c802c7b378146d318645#18}'; endif;echo translate_smarty(array('id' => 'new_course'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:4a84f8d70399c802c7b378146d318645#18}'; endif;?>
</a></p>
<?php else: ?>
<p><a href="<?php if ($this->caching && !$this->_cache_including): echo '{nocache:4a84f8d70399c802c7b378146d318645#19}'; endif;echo url_smarty(array('page' => 'editcourse','id' => 'new'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:4a84f8d70399c802c7b378146d318645#19}'; endif;?>
"><?php if ($this->caching && !$this->_cache_including): echo '{nocache:4a84f8d70399c802c7b378146d318645#20}'; endif;echo translate_smarty(array('id' => 'new_course'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:4a84f8d70399c802c7b378146d318645#20}'; endif;?>
</a></p>
<?php endif; ?>

<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'include/footer.tpl', 'smarty_include_vars' => array('noad' => 1)));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>