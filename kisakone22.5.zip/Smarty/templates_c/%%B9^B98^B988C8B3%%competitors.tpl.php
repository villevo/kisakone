<?php /* Smarty version 2.6.28, created on 2016-05-21 03:22:17
         compiled from eventviews/competitors.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'url', 'eventviews/competitors.tpl', 28, false),array('function', 'initializeGetFormFields', 'eventviews/competitors.tpl', 29, false),array('function', 'translate', 'eventviews/competitors.tpl', 31, false),array('function', 'sortheading', 'eventviews/competitors.tpl', 40, false),array('modifier', 'escape', 'eventviews/competitors.tpl', 32, false),array('modifier', 'lower', 'eventviews/competitors.tpl', 54, false),)), $this); ?>
<?php $this->_cache_serials['./Smarty/templates_c\%%B9^B98^B988C8B3%%competitors.tpl.inc'] = '5ff2663a9a7e519dd4d2a77d23dd03dc'; ?><?php if ($this->_tpl_vars['mode'] == 'body'): ?>
<div id="event_content">
    <?php echo $this->_tpl_vars['page']->formattedText; ?>

</div>

<form method="get" class="usersform" action="<?php if ($this->caching && !$this->_cache_including): echo '{nocache:5ff2663a9a7e519dd4d2a77d23dd03dc#0}'; endif;echo url_smarty(array('page' => 'event','view' => 'competitors','id' => $_GET['id']), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:5ff2663a9a7e519dd4d2a77d23dd03dc#0}'; endif;?>
">
    <?php if ($this->caching && !$this->_cache_including): echo '{nocache:5ff2663a9a7e519dd4d2a77d23dd03dc#1}'; endif;echo initializeGetFormFields_Smarty(array('search' => false), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:5ff2663a9a7e519dd4d2a77d23dd03dc#1}'; endif;?>

    <div class="formelements">
        <p><?php if ($this->caching && !$this->_cache_including): echo '{nocache:5ff2663a9a7e519dd4d2a77d23dd03dc#2}'; endif;echo translate_smarty(array('id' => 'users_searchhint'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:5ff2663a9a7e519dd4d2a77d23dd03dc#2}'; endif;?>
</p>
        <input id="searchField" type="text" size="30" name="search" value="<?php echo ((is_array($_tmp=$_GET['search'])) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
" />
        <input type="submit" value="<?php if ($this->caching && !$this->_cache_including): echo '{nocache:5ff2663a9a7e519dd4d2a77d23dd03dc#3}'; endif;echo translate_smarty(array('id' => 'users_search'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:5ff2663a9a7e519dd4d2a77d23dd03dc#3}'; endif;?>
" />
    </div>
</form>
<hr style="clear: both;" />
<div class="SearchStatus" />
<table class="narrow" style="min-width: 500px">
    <tr>
        <th><?php if ($this->caching && !$this->_cache_including): echo '{nocache:5ff2663a9a7e519dd4d2a77d23dd03dc#4}'; endif;echo sortheading_smarty(array('field' => 1,'id' => 'num','sortType' => 'integer'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:5ff2663a9a7e519dd4d2a77d23dd03dc#4}'; endif;?>
</th>
        <th><?php if ($this->caching && !$this->_cache_including): echo '{nocache:5ff2663a9a7e519dd4d2a77d23dd03dc#5}'; endif;echo sortheading_smarty(array('field' => 'LastName','id' => 'lastname','sortType' => 'alphabetical'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:5ff2663a9a7e519dd4d2a77d23dd03dc#5}'; endif;?>
</th>
        <th><?php if ($this->caching && !$this->_cache_including): echo '{nocache:5ff2663a9a7e519dd4d2a77d23dd03dc#6}'; endif;echo sortheading_smarty(array('field' => 'FirstName','id' => 'firstname','sortType' => 'alphabetical'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:5ff2663a9a7e519dd4d2a77d23dd03dc#6}'; endif;?>
</th>
        <th><?php if ($this->caching && !$this->_cache_including): echo '{nocache:5ff2663a9a7e519dd4d2a77d23dd03dc#7}'; endif;echo sortheading_smarty(array('field' => 'ClubName','id' => 'clubname','sortType' => 'alphabetical'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:5ff2663a9a7e519dd4d2a77d23dd03dc#7}'; endif;?>
</th>
        <th><?php if ($this->caching && !$this->_cache_including): echo '{nocache:5ff2663a9a7e519dd4d2a77d23dd03dc#8}'; endif;echo sortheading_smarty(array('field' => 'ClassName','id' => 'class','sortType' => 'alphabetical'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:5ff2663a9a7e519dd4d2a77d23dd03dc#8}'; endif;?>
</th>
        <th><?php if ($this->caching && !$this->_cache_including): echo '{nocache:5ff2663a9a7e519dd4d2a77d23dd03dc#9}'; endif;echo sortheading_smarty(array('field' => 'PDGA','id' => 'users_pdga','sortType' => 'integer'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:5ff2663a9a7e519dd4d2a77d23dd03dc#9}'; endif;?>
</th>
        <?php if ($this->_tpl_vars['pdga_enabled']): ?><th><?php if ($this->caching && !$this->_cache_including): echo '{nocache:5ff2663a9a7e519dd4d2a77d23dd03dc#10}'; endif;echo sortheading_smarty(array('field' => 'Rating','id' => 'pdga_rating','sortType' => 'integer'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:5ff2663a9a7e519dd4d2a77d23dd03dc#10}'; endif;?>
</th><?php endif; ?>
    </tr>
    <?php $_from = $this->_tpl_vars['participants']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }$this->_foreach['osallistuja'] = array('total' => count($_from), 'iteration' => 0);
if ($this->_foreach['osallistuja']['total'] > 0):
    foreach ($_from as $this->_tpl_vars['participant']):
        $this->_foreach['osallistuja']['iteration']++;
?>
    <tr>
        <?php $this->assign('country', $this->_tpl_vars['participant']['PDGACountry']); ?>
        <?php if (! $this->_tpl_vars['country']): ?><?php $this->assign('country', 'FI'); ?><?php endif; ?>
        <td><?php echo ($this->_foreach['osallistuja']['iteration']-1)+1; ?>
</td>
        <td>
        <span class="flag-icon flag-icon-<?php echo ((is_array($_tmp=$this->_tpl_vars['country'])) ? $this->_run_mod_handler('lower', true, $_tmp) : smarty_modifier_lower($_tmp)); ?>
"></span>
        <?php if ($this->_tpl_vars['participant']['user']->username): ?><a href="<?php if ($this->caching && !$this->_cache_including): echo '{nocache:5ff2663a9a7e519dd4d2a77d23dd03dc#11}'; endif;echo url_smarty(array('page' => 'user','id' => $this->_tpl_vars['participant']['user']->username), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:5ff2663a9a7e519dd4d2a77d23dd03dc#11}'; endif;?>
"><?php endif; ?>
        <?php echo ((is_array($_tmp=$this->_tpl_vars['participant']['user']->lastname)) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>

        <?php if ($this->_tpl_vars['participant']['user']->username): ?></a><?php endif; ?>
        </td>
        <td>
        <?php if ($this->_tpl_vars['participant']['user']->username): ?><a href="<?php if ($this->caching && !$this->_cache_including): echo '{nocache:5ff2663a9a7e519dd4d2a77d23dd03dc#12}'; endif;echo url_smarty(array('page' => 'user','id' => $this->_tpl_vars['participant']['user']->username), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:5ff2663a9a7e519dd4d2a77d23dd03dc#12}'; endif;?>
"><?php endif; ?>
        <?php echo ((is_array($_tmp=$this->_tpl_vars['participant']['user']->firstname)) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>

        <?php if ($this->_tpl_vars['participant']['user']->username): ?></a><?php endif; ?>
        </td>
    
        <td><abbr title="<?php echo ((is_array($_tmp=$this->_tpl_vars['participant']['clubLongName'])) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
"><?php echo ((is_array($_tmp=$this->_tpl_vars['participant']['clubName'])) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
</abbr></td>

        <td><abbr title="<?php echo ((is_array($_tmp=$this->_tpl_vars['participant']['className'])) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
"><?php echo ((is_array($_tmp=$this->_tpl_vars['participant']['classShort'])) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
</abbr></td>
        <td><?php echo ((is_array($_tmp=$this->_tpl_vars['participant']['player']->pdga)) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
</td>
        <?php if ($this->_tpl_vars['pdga_enabled']): ?><td><?php echo ((is_array($_tmp=$this->_tpl_vars['participant']['rating'])) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
</td><?php endif; ?>
    </tr>
    <?php endforeach; endif; unset($_from); ?>
</table>

<div class="SearchStatus" />

<script type="text/javascript">
//<![CDATA[
<?php echo '
$(document).ready(function(){
    TableSearch(document.getElementById(\'searchField\'), document.getElementById(\'userTable\'),
                '; ?>
"<?php if ($this->caching && !$this->_cache_including): echo '{nocache:5ff2663a9a7e519dd4d2a77d23dd03dc#13}'; endif;echo translate_smarty(array('id' => 'No_Search_Results'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:5ff2663a9a7e519dd4d2a77d23dd03dc#13}'; endif;?>
"<?php echo '
                );
    $($(".SortHeading").get(0)).click();
});

'; ?>

//]]>
</script>

<?php endif; ?>