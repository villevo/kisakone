<?php /* Smarty version 2.6.28, created on 2016-05-21 02:46:31
         compiled from redirect.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'translate', 'redirect.tpl', 26, false),array('modifier', 'escape', 'redirect.tpl', 36, false),)), $this); ?>
<?php $this->_cache_serials['./Smarty/templates_c\%%77^770^770CF2DB%%redirect.tpl.inc'] = '685ead03efbbd60c1ecbd2d58f0bbb3a'; ?>
<?php $this->assign('server', $_SERVER['SERVER']); ?>
<?php if ($this->_tpl_vars['data'] == 'login'): ?>
  <?php if ($this->caching && !$this->_cache_including): echo '{nocache:685ead03efbbd60c1ecbd2d58f0bbb3a#0}'; endif;echo translate_smarty(array('assign' => 'title','id' => 'loginredirect_title'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:685ead03efbbd60c1ecbd2d58f0bbb3a#0}'; endif;?>

  <?php if ($this->caching && !$this->_cache_including): echo '{nocache:685ead03efbbd60c1ecbd2d58f0bbb3a#1}'; endif;echo translate_smarty(array('assign' => 'text','id' => 'loginredirect_text'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:685ead03efbbd60c1ecbd2d58f0bbb3a#1}'; endif;?>

<?php elseif ($this->_tpl_vars['data'] == 'login_change_password'): ?>
  <?php if ($this->caching && !$this->_cache_including): echo '{nocache:685ead03efbbd60c1ecbd2d58f0bbb3a#2}'; endif;echo translate_smarty(array('assign' => 'title','id' => 'loginpassword_title'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:685ead03efbbd60c1ecbd2d58f0bbb3a#2}'; endif;?>

  <?php if ($this->caching && !$this->_cache_including): echo '{nocache:685ead03efbbd60c1ecbd2d58f0bbb3a#3}'; endif;echo translate_smarty(array('assign' => 'text','id' => 'loginpassword_text'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:685ead03efbbd60c1ecbd2d58f0bbb3a#3}'; endif;?>

<?php endif; ?>

<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "include/header.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>

<p><?php echo $this->_tpl_vars['text']; ?>
</p>
<p><a href="<?php echo $this->_tpl_vars['server']; ?>
<?php echo ((is_array($_tmp=$this->_tpl_vars['url'])) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
"><?php if ($this->caching && !$this->_cache_including): echo '{nocache:685ead03efbbd60c1ecbd2d58f0bbb3a#4}'; endif;echo translate_smarty(array('id' => 'redirect_proceed'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:685ead03efbbd60c1ecbd2d58f0bbb3a#4}'; endif;?>
</a></p>

<script type="text/javascript">
//<![CDATA[
var url = "<?php echo ((is_array($_tmp=$this->_tpl_vars['url'])) ? $this->_run_mod_handler('escape', true, $_tmp, 'javascript') : smarty_modifier_escape($_tmp, 'javascript')); ?>
";
<?php echo '
setTimeout(doRedirect, 3000);

function doRedirect() {
    window.location = url;
}
'; ?>

//]]>
</script>

<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "include/footer.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>