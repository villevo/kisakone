<?php /* Smarty version 2.6.28, created on 2016-05-22 01:25:52
         compiled from user.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'translate', 'user.tpl', 23, false),array('modifier', 'escape', 'user.tpl', 26, false),)), $this); ?>
<?php $this->_cache_serials['./Smarty/templates_c\%%FF^FF1^FF17EB69%%user.tpl.inc'] = '541fbdc6529760f144030358997cbd13'; ?><?php if ($this->caching && !$this->_cache_including): echo '{nocache:541fbdc6529760f144030358997cbd13#0}'; endif;echo translate_smarty(array('id' => 'users_title','assign' => 'title'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:541fbdc6529760f144030358997cbd13#0}'; endif;?>

<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'include/header.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>

<h2><?php if ($this->caching && !$this->_cache_including): echo '{nocache:541fbdc6529760f144030358997cbd13#1}'; endif;echo translate_smarty(array('id' => 'user_header','user' => ((is_array($_tmp=$this->_tpl_vars['userinfo']->username)) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp))), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:541fbdc6529760f144030358997cbd13#1}'; endif;?>
</h2>

<table style="width:800px">
   <tr>
      <td style="width: 200px"><?php if ($this->caching && !$this->_cache_including): echo '{nocache:541fbdc6529760f144030358997cbd13#2}'; endif;echo translate_smarty(array('id' => 'user_name'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:541fbdc6529760f144030358997cbd13#2}'; endif;?>
: </td>
      <td><?php echo ((is_array($_tmp=$this->_tpl_vars['userinfo']->fullname)) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
</td>
   </tr>
   <?php if ($this->_tpl_vars['player']): ?>
      <tr>
         <td><?php if ($this->caching && !$this->_cache_including): echo '{nocache:541fbdc6529760f144030358997cbd13#3}'; endif;echo translate_smarty(array('id' => 'user_gender'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:541fbdc6529760f144030358997cbd13#3}'; endif;?>
: </td>
         <td><?php ob_start(); ?>gender_<?php echo $this->_tpl_vars['player']->gender; ?>
<?php $this->_smarty_vars['capture']['default'] = ob_get_contents();  $this->assign('gendertoken', ob_get_contents());ob_end_clean(); ?>
         <?php if ($this->caching && !$this->_cache_including): echo '{nocache:541fbdc6529760f144030358997cbd13#4}'; endif;echo translate_smarty(array('id' => $this->_tpl_vars['gendertoken']), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:541fbdc6529760f144030358997cbd13#4}'; endif;?>
</td>
      </tr>
      <tr>
      <?php if ($this->_tpl_vars['pdga_country'] && $this->_tpl_vars['pdga_country'] != 'FI'): ?>
         <td><?php if ($this->caching && !$this->_cache_including): echo '{nocache:541fbdc6529760f144030358997cbd13#5}'; endif;echo translate_smarty(array('id' => 'user_country'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:541fbdc6529760f144030358997cbd13#5}'; endif;?>
:</td>
         <td><?php if ($this->_tpl_vars['pdga_state']): ?><?php echo $this->_tpl_vars['pdga_state']; ?>
, <?php endif; ?><?php echo $this->_tpl_vars['pdga_country']; ?>
</td>
      <?php endif; ?>
	<td><?php if ($this->caching && !$this->_cache_including): echo '{nocache:541fbdc6529760f144030358997cbd13#6}'; endif;echo translate_smarty(array('id' => 'user_club'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:541fbdc6529760f144030358997cbd13#6}'; endif;?>
:</td>
         <td><?php echo ((is_array($_tmp=$this->_tpl_vars['user_club_data']['Name'])) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
 <?php if ($this->_tpl_vars['user_club_data']['ShortName']): ?> (<?php echo ((is_array($_tmp=$this->_tpl_vars['user_club_data']['ShortName'])) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
) <?php else: ?> <?php if ($this->caching && !$this->_cache_including): echo '{nocache:541fbdc6529760f144030358997cbd13#7}'; endif;echo translate_smarty(array('id' => 'club_use_no_club'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:541fbdc6529760f144030358997cbd13#7}'; endif;?>
 <?php endif; ?></td>

		 
		 
		 
      </tr>
      <tr>
         <td><?php if ($this->caching && !$this->_cache_including): echo '{nocache:541fbdc6529760f144030358997cbd13#8}'; endif;echo translate_smarty(array('id' => 'user_yearofbirth'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:541fbdc6529760f144030358997cbd13#8}'; endif;?>
: </td>
         <td><?php echo ((is_array($_tmp=$this->_tpl_vars['player']->birthyear)) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
</td>
      </tr>
      <tr>
         <td>Tasoitus nyt: </td>
         <td><?php if (((is_array($_tmp=$this->_tpl_vars['player']->hcp)) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)) > 0): ?>+<?php endif; ?><?php echo ((is_array($_tmp=$this->_tpl_vars['player']->hcp)) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
</td>
      </tr>      
   <?php else: ?>
      <tr><td colspan="2">
         <?php if ($this->caching && !$this->_cache_including): echo '{nocache:541fbdc6529760f144030358997cbd13#9}'; endif;echo translate_smarty(array('id' => 'user_not_player'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:541fbdc6529760f144030358997cbd13#9}'; endif;?>

      </td></tr>
   <?php endif; ?>
</table>

<?php if ($this->_tpl_vars['sfl_enabled']): ?>
<?php if (( $this->_tpl_vars['itsme'] || $this->_tpl_vars['isadmin'] ) && $this->_tpl_vars['player']): ?>
   <h2><?php if ($this->caching && !$this->_cache_including): echo '{nocache:541fbdc6529760f144030358997cbd13#10}'; endif;echo translate_smarty(array('id' => 'user_licenses_title'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:541fbdc6529760f144030358997cbd13#10}'; endif;?>
</h2>

   <?php if ($this->_tpl_vars['sfl_enabled'] && ! $this->_tpl_vars['data']): ?>
      <?php if (! $this->_tpl_vars['pdga_enabled'] || $this->_tpl_vars['pdga_country'] == 'FI'): ?>
      <p class="error"><?php if ($this->caching && !$this->_cache_including): echo '{nocache:541fbdc6529760f144030358997cbd13#11}'; endif;echo translate_smarty(array('id' => 'check_registry_data'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:541fbdc6529760f144030358997cbd13#11}'; endif;?>
</p>
      <?php endif; ?>
   <?php endif; ?>

   <table style="width:500px">
   <?php if ($this->_tpl_vars['licenses']): ?>
      <tr>
         <td style="width: 200px"><?php if ($this->caching && !$this->_cache_including): echo '{nocache:541fbdc6529760f144030358997cbd13#12}'; endif;echo translate_smarty(array('id' => 'user_membershipfee'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:541fbdc6529760f144030358997cbd13#12}'; endif;?>
: </td>
         <td>
            <?php $_from = $this->_tpl_vars['licenses']['membership']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['year'] => $this->_tpl_vars['paid']):
?>
               <?php if ($this->_tpl_vars['paid']): ?>
                  <?php echo $this->_tpl_vars['year']; ?>
 <?php if ($this->caching && !$this->_cache_including): echo '{nocache:541fbdc6529760f144030358997cbd13#13}'; endif;echo translate_smarty(array('id' => 'user_ispaid'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:541fbdc6529760f144030358997cbd13#13}'; endif;?>

               <?php else: ?>
                  <?php echo $this->_tpl_vars['year']; ?>
 <?php if ($this->caching && !$this->_cache_including): echo '{nocache:541fbdc6529760f144030358997cbd13#14}'; endif;echo translate_smarty(array('id' => 'user_notpaid'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:541fbdc6529760f144030358997cbd13#14}'; endif;?>

               <?php endif; ?>
               <br />
            <?php endforeach; endif; unset($_from); ?>
         </td>
      </tr>
      <tr>
         <td ><?php if ($this->caching && !$this->_cache_including): echo '{nocache:541fbdc6529760f144030358997cbd13#15}'; endif;echo translate_smarty(array('id' => 'user_licensefee'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:541fbdc6529760f144030358997cbd13#15}'; endif;?>
: </td>
         <td>
            <?php $_from = $this->_tpl_vars['licenses']['license']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['year'] => $this->_tpl_vars['paid']):
?>
               <?php if ($this->_tpl_vars['paid']): ?>
                  <?php $this->assign('license_paid', true); ?>
                  <?php echo $this->_tpl_vars['year']; ?>
 <?php if ($this->caching && !$this->_cache_including): echo '{nocache:541fbdc6529760f144030358997cbd13#16}'; endif;echo translate_smarty(array('id' => 'user_ispaid'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:541fbdc6529760f144030358997cbd13#16}'; endif;?>

               <?php else: ?>
                  <?php echo $this->_tpl_vars['year']; ?>
 <?php if ($this->caching && !$this->_cache_including): echo '{nocache:541fbdc6529760f144030358997cbd13#17}'; endif;echo translate_smarty(array('id' => 'user_notpaid'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:541fbdc6529760f144030358997cbd13#17}'; endif;?>

               <?php endif; ?>
               <br />
            <?php endforeach; endif; unset($_from); ?>
         </td>
      </tr>
   <?php endif; ?>
   </table>
<?php endif; ?>
<?php endif; ?>


<?php if ($this->_tpl_vars['player'] && $this->_tpl_vars['player']->pdga): ?>
<h2><?php if ($this->caching && !$this->_cache_including): echo '{nocache:541fbdc6529760f144030358997cbd13#18}'; endif;echo translate_smarty(array('id' => 'user_pdga_title'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:541fbdc6529760f144030358997cbd13#18}'; endif;?>
</h2>

<table style="width:335px">

 <tr>
    <td><label for="pdga_number"><?php if ($this->caching && !$this->_cache_including): echo '{nocache:541fbdc6529760f144030358997cbd13#19}'; endif;echo translate_smarty(array('id' => 'pdga_number'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:541fbdc6529760f144030358997cbd13#19}'; endif;?>
</label></td>
    <td><span id="pdga_number"><a href="http://www.pdga.com/player/<?php echo $this->_tpl_vars['player']->pdga; ?>
"><?php echo $this->_tpl_vars['player']->pdga; ?>
</a></span></td>
</tr>



<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'include/pdgainfotable.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
</table>
<?php endif; ?>


<?php if ($this->_tpl_vars['isadmin']): ?>
<h2><?php if ($this->caching && !$this->_cache_including): echo '{nocache:541fbdc6529760f144030358997cbd13#20}'; endif;echo translate_smarty(array('id' => 'admin_user_options'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:541fbdc6529760f144030358997cbd13#20}'; endif;?>
</h2>



<?php if ($this->_tpl_vars['emailverification_enabled']): ?>
<form method="post">
    <input type="hidden" name="formid" value="email_verification" />
    <input type="hidden" name="email" value="<?php echo $this->_tpl_vars['email']; ?>
" />
    <input type="hidden" name="token" value="<?php echo $this->_tpl_vars['emailverification_token']; ?>
" />
    <input type="hidden" name="email_user" value="<?php echo $this->_tpl_vars['email_user']; ?>
" />

    <input type="submit" value="<?php if ($this->caching && !$this->_cache_including): echo '{nocache:541fbdc6529760f144030358997cbd13#21}'; endif;echo translate_smarty(array('id' => 'admin_verify_user_email'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:541fbdc6529760f144030358997cbd13#21}'; endif;?>
" <?php if ($this->_tpl_vars['emailverified']): ?>disabled="disabled"<?php endif; ?> />
</form>
<?php endif; ?>

<?php endif; ?>

<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'include/hcp_info.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>

<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'include/footer.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>