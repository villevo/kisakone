<?php /* Smarty version 2.6.28, created on 2016-05-20 22:52:46
         compiled from include/header.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'translate', 'include/header.tpl', 27, false),)), $this); ?>
<?php $this->_cache_serials['./Smarty/templates_c\%%4C^4C3^4C3A410D%%header.tpl.inc'] = 'c4b7c2d2290884e1da5dcfa5742a937d'; ?><!doctype html>
<html lang="fi-FI">
<meta charset="utf-8">

<title><?php echo $this->_tpl_vars['title']; ?>
 - <?php if ($this->caching && !$this->_cache_including): echo '{nocache:c4b7c2d2290884e1da5dcfa5742a937d#0}'; endif;echo translate_smarty(array('id' => 'site_name'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:c4b7c2d2290884e1da5dcfa5742a937d#0}'; endif;?>
</title>
<link rel="stylesheet" href="<?php echo $this->_tpl_vars['url_base']; ?>
css/style.css">
<link rel="stylesheet" href="<?php echo $this->_tpl_vars['url_base']; ?>
css/custom.css">
<link rel="apple-touch-icon" href="<?php echo $this->_tpl_vars['url_base']; ?>
images/apple-touch-icon.png">
<script src="<?php echo $this->_tpl_vars['url_base']; ?>
js/jquery-1.11.2.min.js"></script>
<script src=<?php if ($this->_tpl_vars['mod_rewrite']): ?>"<?php echo $this->_tpl_vars['url_base']; ?>
javascript/base"<?php else: ?>"<?php echo $this->_tpl_vars['url_base']; ?>
index.php?page=javascript/base"<?php endif; ?> defer></script>

<link rel="stylesheet" href="<?php echo $this->_tpl_vars['url_base']; ?>
css/flag-icon/css/flag-icon.min.css">

<link href='https://fonts.googleapis.com/css?family=Oswald:400,700,300' rel='stylesheet' type='text/css'>

<?php if ($this->_tpl_vars['ui']): ?>
<script src="<?php echo $this->_tpl_vars['url_base']; ?>
js/jquery-ui-1.11.2.min.js" defer></script>
<link rel="stylesheet" href="<?php echo $this->_tpl_vars['url_base']; ?>
js/jquery-ui-lightness/jquery-ui.min.css">
<?php endif; ?>
<?php if ($this->_tpl_vars['timepicker']): ?>
<script src="<?php echo $this->_tpl_vars['url_base']; ?>
js/jquery/jquery-ui-timepicker-addon.min.js" defer></script>
<script src="<?php echo $this->_tpl_vars['url_base']; ?>
js/jquery/jquery-ui-sliderAccess.js" defer></script>
<link rel="stylesheet" href="<?php echo $this->_tpl_vars['url_base']; ?>
js/jquery/jquery-ui-timepicker-addon.min.css">
<?php endif; ?>
<?php if ($this->_tpl_vars['autocomplete']): ?>
<script src="<?php echo $this->_tpl_vars['url_base']; ?>
js/jquery/jquery.autocomplete-min.js" defer></script>
<?php endif; ?>
<?php if ($this->_tpl_vars['tooltip']): ?>
<?php echo '<script>$(function() { $( document ).tooltip(); });'; ?>
 </script>
<?php endif; ?>
<?php if ($this->_tpl_vars['analytics']): ?>
<script src="<?php echo $this->_tpl_vars['url_base']; ?>
js/analytics.js" defer></script>
<?php endif; ?>
<?php if ($this->_tpl_vars['trackjs']): ?>
<script src="https://d2zah9y47r7bi2.cloudfront.net/releases/current/tracker.js" data-token="<?php echo $this->_tpl_vars['trackjs']; ?>
" defer></script>
<?php endif; ?>
<?php if ($this->_tpl_vars['calendar']): ?>
<script src="<?php echo $this->_tpl_vars['url_base']; ?>
js/addthisevent/ate.min.js" defer></script>
<link rel="stylesheet" href="<?php echo $this->_tpl_vars['url_base']; ?>
js/addthisevent/ate.css" />
<?php endif; ?>
<!-- Font Awesome CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">
<?php echo $this->_tpl_vars['extrahead']; ?>

<meta name="x-kisakone-version" content="<?php echo $this->_tpl_vars['kisakone_version']; ?>
">

<!--[if lt IE 9]>
    <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
<![endif]-->
<?php echo '
<script>
  (function(i,s,o,g,r,a,m){i[\'GoogleAnalyticsObject\']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,\'script\',\'https://www.google-analytics.com/analytics.js\',\'ga\');

  ga(\'create\', \'UA-68882198-2\', \'auto\');
  ga(\'send\', \'pageview\');

</script>
'; ?>

<body>


        <header id="header">
			<div class="head_container container_widht">
				<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "include/loginbox.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
					<img id="sitelogo" src="http://www.rolffarit.com/kisakone/images/sitelogo.png" alt="<?php if ($this->caching && !$this->_cache_including): echo '{nocache:c4b7c2d2290884e1da5dcfa5742a937d#1}'; endif;echo translate_smarty(array('id' => 'site_name'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:c4b7c2d2290884e1da5dcfa5742a937d#1}'; endif;?>
" />
					<div class="sitetitles">
						<div id="sitename"><?php if ($this->caching && !$this->_cache_including): echo '{nocache:c4b7c2d2290884e1da5dcfa5742a937d#2}'; endif;echo translate_smarty(array('id' => 'site_name_long'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:c4b7c2d2290884e1da5dcfa5742a937d#2}'; endif;?>
</div>
						<div id="pagename"><?php echo $this->_tpl_vars['title']; ?>
</div>
					</div>
			</div>
        </header>
    <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "include/mainmenu.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>

<div class="outer_container">
<div class="container container_widht">
<table id="headdiv" cellpadding="0" cellspacing="0">
    <tr id="maintr2" class="maintti">
        <td id="submenucontainer">        <br />
            <?php echo $this->_tpl_vars['submenu_content']; ?>


            <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => "include/submenu.tpl", 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
        </td>
        <td id="content">