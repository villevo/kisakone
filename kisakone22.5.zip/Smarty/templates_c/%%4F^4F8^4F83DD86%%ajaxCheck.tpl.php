<?php /* Smarty version 2.6.28, created on 2016-05-20 23:48:28
         compiled from ajaxCheck.tpl */ ?>
<?php echo $this->_tpl_vars['data']; ?>
