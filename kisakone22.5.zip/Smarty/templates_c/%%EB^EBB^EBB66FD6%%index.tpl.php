<?php /* Smarty version 2.6.28, created on 2016-05-21 00:23:06
         compiled from eventviews/index.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'translate', 'eventviews/index.tpl', 36, false),array('function', 'math', 'eventviews/index.tpl', 99, false),array('function', 'url', 'eventviews/index.tpl', 120, false),array('modifier', 'escape', 'eventviews/index.tpl', 37, false),array('modifier', 'date_format', 'eventviews/index.tpl', 101, false),)), $this); ?>
<?php $this->_cache_serials['./Smarty/templates_c\%%EB^EBB^EBB66FD6%%index.tpl.inc'] = '5171ef597b0a090920b8f2ab1c662a1b'; ?> <?php if ($this->_tpl_vars['mode'] == 'body'): ?>
 <div id="event_content">
    <?php echo $this->_tpl_vars['page']->formattedText; ?>

</div>

<?php if ($this->_tpl_vars['calendar']): ?>
<div style="float: right; width: 400px;">
    <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'include/calendar.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
</div>
<?php endif; ?>

<table class="narrow">
    <tr>
        <td><?php if ($this->caching && !$this->_cache_including): echo '{nocache:5171ef597b0a090920b8f2ab1c662a1b#0}'; endif;echo translate_smarty(array('id' => 'event_name'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:5171ef597b0a090920b8f2ab1c662a1b#0}'; endif;?>
</td>
        <td><?php echo ((is_array($_tmp=$this->_tpl_vars['event']->name)) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
</td>
    </tr>

    <?php if ($this->_tpl_vars['event']->club): ?>
    <tr>
        <td><?php if ($this->caching && !$this->_cache_including): echo '{nocache:5171ef597b0a090920b8f2ab1c662a1b#1}'; endif;echo translate_smarty(array('id' => 'event_club'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:5171ef597b0a090920b8f2ab1c662a1b#1}'; endif;?>
</td>
        <td><?php echo ((is_array($_tmp=$this->_tpl_vars['event']->GetClubName())) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
</td>
    </tr>
    <?php endif; ?>

    <tr>
        <td><?php if ($this->caching && !$this->_cache_including): echo '{nocache:5171ef597b0a090920b8f2ab1c662a1b#2}'; endif;echo translate_smarty(array('id' => 'event_venue'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:5171ef597b0a090920b8f2ab1c662a1b#2}'; endif;?>
</td>
        <td><?php echo ((is_array($_tmp=$this->_tpl_vars['event']->venue)) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
</td>
    </tr>

    <tr>
        <td><?php if ($this->caching && !$this->_cache_including): echo '{nocache:5171ef597b0a090920b8f2ab1c662a1b#3}'; endif;echo translate_smarty(array('id' => 'event_date'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:5171ef597b0a090920b8f2ab1c662a1b#3}'; endif;?>
</td>
        <td><?php echo ((is_array($_tmp=$this->_tpl_vars['event']->fulldate)) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
</td>
    </tr>

    <?php if ($this->_tpl_vars['event']->level): ?>
    <tr>
        <td><?php if ($this->caching && !$this->_cache_including): echo '{nocache:5171ef597b0a090920b8f2ab1c662a1b#4}'; endif;echo translate_smarty(array('id' => 'event_level'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:5171ef597b0a090920b8f2ab1c662a1b#4}'; endif;?>
</td>
        <td><?php echo ((is_array($_tmp=$this->_tpl_vars['event']->level)) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
</td>
    </tr>
    <?php endif; ?>

    <?php if ($this->_tpl_vars['event']->tournament): ?>
    <tr>
        <td><?php if ($this->caching && !$this->_cache_including): echo '{nocache:5171ef597b0a090920b8f2ab1c662a1b#5}'; endif;echo translate_smarty(array('id' => 'event_tournament'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:5171ef597b0a090920b8f2ab1c662a1b#5}'; endif;?>
</td>
        <td><?php echo ((is_array($_tmp=$this->_tpl_vars['event']->tournament)) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
</td>
    </tr>
    <?php endif; ?>

    <tr>
        <td><?php if ($this->caching && !$this->_cache_including): echo '{nocache:5171ef597b0a090920b8f2ab1c662a1b#6}'; endif;echo translate_smarty(array('id' => 'event_contact'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:5171ef597b0a090920b8f2ab1c662a1b#6}'; endif;?>
</td>
        <td id="contactInfo"><div style="font-family: monospace"><?php echo $this->_tpl_vars['contactInfoHTML']; ?>
</div></td>
    </tr>

    <?php if ($this->_tpl_vars['pdgaUrl']): ?>
    <tr>
        <td><?php if ($this->caching && !$this->_cache_including): echo '{nocache:5171ef597b0a090920b8f2ab1c662a1b#7}'; endif;echo translate_smarty(array('id' => 'event_pdga_url'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:5171ef597b0a090920b8f2ab1c662a1b#7}'; endif;?>
</td>
        <td><a href="<?php echo $this->_tpl_vars['pdgaUrl']; ?>
"><?php echo $this->_tpl_vars['pdgaUrl']; ?>
</a></td>
    </tr>
    <?php endif; ?>
</table>

<h2><?php if ($this->caching && !$this->_cache_including): echo '{nocache:5171ef597b0a090920b8f2ab1c662a1b#8}'; endif;echo translate_smarty(array('id' => 'schedule'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:5171ef597b0a090920b8f2ab1c662a1b#8}'; endif;?>
</h2>

<?php echo $this->_tpl_vars['index_schedule_text']; ?>


<table>
   <tr>
    <th><?php if ($this->caching && !$this->_cache_including): echo '{nocache:5171ef597b0a090920b8f2ab1c662a1b#9}'; endif;echo translate_smarty(array('id' => 'round_number','number' => ''), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:5171ef597b0a090920b8f2ab1c662a1b#9}'; endif;?>
</th>
    <th><?php if ($this->caching && !$this->_cache_including): echo '{nocache:5171ef597b0a090920b8f2ab1c662a1b#10}'; endif;echo translate_smarty(array('id' => 'round_starttime'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:5171ef597b0a090920b8f2ab1c662a1b#10}'; endif;?>
</th>
    <?php if ($this->_tpl_vars['groups']): ?>
    <th><?php if ($this->caching && !$this->_cache_including): echo '{nocache:5171ef597b0a090920b8f2ab1c662a1b#11}'; endif;echo translate_smarty(array('id' => 'your_group_is'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:5171ef597b0a090920b8f2ab1c662a1b#11}'; endif;?>
</th>
    <?php endif; ?>
    </tr>
    <?php $_from = $this->_tpl_vars['rounds']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['index'] => $this->_tpl_vars['round']):
?>

    <tr>
        <?php echo smarty_function_math(array('assign' => 'number','equation' => "x+1",'x' => $this->_tpl_vars['index']), $this);?>

        <td><?php if ($this->caching && !$this->_cache_including): echo '{nocache:5171ef597b0a090920b8f2ab1c662a1b#12}'; endif;echo translate_smarty(array('id' => 'round_number','number' => $this->_tpl_vars['number']), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:5171ef597b0a090920b8f2ab1c662a1b#12}'; endif;?>
</td>
        <td><?php echo ((is_array($_tmp=$this->_tpl_vars['round']->starttime)) ? $this->_run_mod_handler('date_format', true, $_tmp, "%d.%m.%Y %H:%M") : smarty_modifier_date_format($_tmp, "%d.%m.%Y %H:%M")); ?>
</td>

        <?php $this->assign('group', $this->_tpl_vars['groups'][$this->_tpl_vars['index']]); ?>
        <?php if ($this->_tpl_vars['group']): ?>
        <td>
        <?php if ($this->_tpl_vars['round']->groupsFinished !== null): ?>
            <?php if ($this->_tpl_vars['round']->starttype == 'sequential'): ?>
        <?php ob_start(); ?><?php echo ((is_array($_tmp=$this->_tpl_vars['group']['StartingTime'])) ? $this->_run_mod_handler('date_format', true, $_tmp, "%H:%M") : smarty_modifier_date_format($_tmp, "%H:%M")); ?>
<?php $this->_smarty_vars['capture']['default'] = ob_get_contents();  $this->assign('groupstart', ob_get_contents());ob_end_clean(); ?>
        <?php if ($this->caching && !$this->_cache_including): echo '{nocache:5171ef597b0a090920b8f2ab1c662a1b#13}'; endif;echo translate_smarty(array('id' => 'your_group_starting','start' => $this->_tpl_vars['groupstart']), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:5171ef597b0a090920b8f2ab1c662a1b#13}'; endif;?>

        <?php else: ?><?php if ($this->caching && !$this->_cache_including): echo '{nocache:5171ef597b0a090920b8f2ab1c662a1b#14}'; endif;echo translate_smarty(array('id' => 'your_group_starting_hole','hole' => $this->_tpl_vars['group']['StartingHole']), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:5171ef597b0a090920b8f2ab1c662a1b#14}'; endif;?>
<?php endif; ?>
        <?php endif; ?>
   </td>
        <?php endif; ?>

    </tr>
    <?php endforeach; endif; unset($_from); ?>

</table>

<p><a href="<?php if ($this->caching && !$this->_cache_including): echo '{nocache:5171ef597b0a090920b8f2ab1c662a1b#15}'; endif;echo url_smarty(array('page' => 'event','id' => $_GET['id'],'view' => 'schedule'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:5171ef597b0a090920b8f2ab1c662a1b#15}'; endif;?>
"><?php if ($this->caching && !$this->_cache_including): echo '{nocache:5171ef597b0a090920b8f2ab1c662a1b#16}'; endif;echo translate_smarty(array('id' => 'full_schedule'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:5171ef597b0a090920b8f2ab1c662a1b#16}'; endif;?>
</a></p>

<h2><?php if ($this->caching && !$this->_cache_including): echo '{nocache:5171ef597b0a090920b8f2ab1c662a1b#17}'; endif;echo translate_smarty(array('id' => 'relevant_news'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:5171ef597b0a090920b8f2ab1c662a1b#17}'; endif;?>
</h2>

<?php $_from = $this->_tpl_vars['news']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['item']):
?>
    <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'eventviews/newsitem.tpl', 'smarty_include_vars' => array('item' => $this->_tpl_vars['item'])));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
<?php endforeach; endif; unset($_from); ?>

<?php if (count ( $this->_tpl_vars['news'] )): ?>
    <p><a href="<?php if ($this->caching && !$this->_cache_including): echo '{nocache:5171ef597b0a090920b8f2ab1c662a1b#18}'; endif;echo url_smarty(array('page' => 'event','id' => $_GET['id'],'view' => 'newsarchive'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:5171ef597b0a090920b8f2ab1c662a1b#18}'; endif;?>
"><?php if ($this->caching && !$this->_cache_including): echo '{nocache:5171ef597b0a090920b8f2ab1c662a1b#19}'; endif;echo translate_smarty(array('id' => 'news_archive'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:5171ef597b0a090920b8f2ab1c662a1b#19}'; endif;?>
</a></p>
    <?php else: ?>
    <p><?php if ($this->caching && !$this->_cache_including): echo '{nocache:5171ef597b0a090920b8f2ab1c662a1b#20}'; endif;echo translate_smarty(array('id' => 'no_news'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:5171ef597b0a090920b8f2ab1c662a1b#20}'; endif;?>
</p>
<?php endif; ?>


<script type="text/javascript">
//<![CDATA[
var ci = new Array();
<?php echo $this->_tpl_vars['contactInfoJS']; ?>


<?php echo '

function getContactInfo() {
    var str = \'\';


    for (var i = 0; i < ci.length; ++i) {
        str += ci[i];
    }

    return str;
}

$(document).ready(function(){

    $("#contactInfo").empty();
    $("#contactInfo").get(0).appendChild(document.createTextNode(getContactInfo()));
});



'; ?>



//]]>
</script>


<?php endif; ?>