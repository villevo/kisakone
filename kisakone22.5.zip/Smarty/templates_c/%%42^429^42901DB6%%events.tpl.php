<?php /* Smarty version 2.6.28, created on 2016-05-21 02:37:06
         compiled from events.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'sortheading', 'events.tpl', 33, false),array('function', 'url', 'events.tpl', 44, false),array('function', 'translate', 'events.tpl', 61, false),array('modifier', 'escape', 'events.tpl', 44, false),array('modifier', 'substr', 'events.tpl', 52, false),)), $this); ?>
<?php $this->_cache_serials['./Smarty/templates_c\%%42^429^42901DB6%%events.tpl.inc'] = '992640918a4e80d6a29a3c826d0f3c48'; ?> <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'include/header.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>

<h2><?php echo $this->_tpl_vars['title']; ?>
<?php if ($this->_tpl_vars['events_count'] > 0): ?> - <?php echo $this->_tpl_vars['events_count']; ?>
 KPL<?php endif; ?></h2>

<?php if ($this->_tpl_vars['error']): ?>
    <p class="error"><?php echo $this->_tpl_vars['error']; ?>
</p>

<?php else: ?>
<table>
    <tr>
        <th><?php if ($this->caching && !$this->_cache_including): echo '{nocache:992640918a4e80d6a29a3c826d0f3c48#0}'; endif;echo sortheading_smarty(array('field' => 'Name','id' => 'event_name','sortType' => 'alphabetical'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:992640918a4e80d6a29a3c826d0f3c48#0}'; endif;?>
</th>
        <th><?php if ($this->caching && !$this->_cache_including): echo '{nocache:992640918a4e80d6a29a3c826d0f3c48#1}'; endif;echo sortheading_smarty(array('field' => 'VenueName','id' => 'event_location','sortType' => 'alphabetical'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:992640918a4e80d6a29a3c826d0f3c48#1}'; endif;?>
</th>
        <th><?php if ($this->caching && !$this->_cache_including): echo '{nocache:992640918a4e80d6a29a3c826d0f3c48#2}'; endif;echo sortheading_smarty(array('field' => 'LevelName','id' => 'event_level','sortType' => 'alphabetical'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:992640918a4e80d6a29a3c826d0f3c48#2}'; endif;?>
</th>
        <th class="classes_max_width"><?php if ($this->caching && !$this->_cache_including): echo '{nocache:992640918a4e80d6a29a3c826d0f3c48#3}'; endif;echo sortheading_smarty(array('field' => 'EventClasses','id' => 'event_classes','sortType' => 'alphabetical'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:992640918a4e80d6a29a3c826d0f3c48#3}'; endif;?>
</th>
        <th><?php if ($this->caching && !$this->_cache_including): echo '{nocache:992640918a4e80d6a29a3c826d0f3c48#4}'; endif;echo sortheading_smarty(array('field' => 'Date','id' => 'event_date','sortType' => 'date'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:992640918a4e80d6a29a3c826d0f3c48#4}'; endif;?>
</th>
        <th></th>
        <th></th>
    </tr>
   <?php $_from = $this->_tpl_vars['events']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['event']):
?>
        <tr>
            <?php if ($this->_tpl_vars['event']->isAccessible()): ?>
            <td><a href="<?php if ($this->caching && !$this->_cache_including): echo '{nocache:992640918a4e80d6a29a3c826d0f3c48#5}'; endif;echo url_smarty(array('page' => 'event','id' => $this->_tpl_vars['event']->id), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:992640918a4e80d6a29a3c826d0f3c48#5}'; endif;?>
"><?php echo ((is_array($_tmp=$this->_tpl_vars['event']->name)) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
</a> </td>
            <?php else: ?>
            <td><?php echo ((is_array($_tmp=$this->_tpl_vars['event']->name)) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
</td>
            <?php endif; ?>
            <td><?php echo ((is_array($_tmp=$this->_tpl_vars['event']->venue)) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
</td>
            <td><?php echo ((is_array($_tmp=$this->_tpl_vars['event']->levelName)) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
</td>
            <td class="classes_max_width">
            <?php $_from = $this->_tpl_vars['event']->GetClasses(); if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['class']):
?>
                <?php if ($this->_tpl_vars['class']->short): ?><?php echo ((is_array($_tmp=$this->_tpl_vars['class']->short)) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
<?php else: ?><?php echo ((is_array($_tmp=((is_array($_tmp=$this->_tpl_vars['class']->name)) ? $this->_run_mod_handler('substr', true, $_tmp, 0, 3) : substr($_tmp, 0, 3)))) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
<?php endif; ?>
            <?php endforeach; else: ?>
                -
            <?php endif; unset($_from); ?>
            </td>
            <td><input type="hidden" value="<?php echo $this->_tpl_vars['event']->date; ?>
" /><?php echo $this->_tpl_vars['event']->fulldate; ?>
</td>

            <td class="event_links">
            <?php if ($this->_tpl_vars['event']->resultsLocked): ?>
                <span class="nowrap"><img src="<?php echo $this->_tpl_vars['url_base']; ?>
images/trophyIcon.png" alt="<?php if ($this->caching && !$this->_cache_including): echo '{nocache:992640918a4e80d6a29a3c826d0f3c48#6}'; endif;echo translate_smarty(array('id' => 'results_available'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:992640918a4e80d6a29a3c826d0f3c48#6}'; endif;?>
" title="<?php if ($this->caching && !$this->_cache_including): echo '{nocache:992640918a4e80d6a29a3c826d0f3c48#7}'; endif;echo translate_smarty(array('id' => 'results_available'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:992640918a4e80d6a29a3c826d0f3c48#7}'; endif;?>
"/>
                <a href="<?php if ($this->caching && !$this->_cache_including): echo '{nocache:992640918a4e80d6a29a3c826d0f3c48#8}'; endif;echo url_smarty(array('page' => 'event','view' => 'leaderboard','id' => $this->_tpl_vars['event']->id), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:992640918a4e80d6a29a3c826d0f3c48#8}'; endif;?>
"><?php if ($this->caching && !$this->_cache_including): echo '{nocache:992640918a4e80d6a29a3c826d0f3c48#9}'; endif;echo translate_smarty(array('id' => 'event_results'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:992640918a4e80d6a29a3c826d0f3c48#9}'; endif;?>
</a></span>

                <?php if ($this->_tpl_vars['event']->standing != null): ?>
                    <?php if ($this->caching && !$this->_cache_including): echo '{nocache:992640918a4e80d6a29a3c826d0f3c48#10}'; endif;echo translate_smarty(array('id' => 'your_standing','standing' => $this->_tpl_vars['event']->standing), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:992640918a4e80d6a29a3c826d0f3c48#10}'; endif;?>

                <?php endif; ?>
            <?php elseif ($this->_tpl_vars['event']->approved !== null): ?>
                                <?php if ($this->_tpl_vars['event']->paymentEnabled): ?>
                    <?php if ($this->_tpl_vars['event']->eventFeePaid): ?>
                        <span class="nowrap"><img src="<?php echo $this->_tpl_vars['url_base']; ?>
images/thumb_up_green.png" width="15" title="<?php if ($this->caching && !$this->_cache_including): echo '{nocache:992640918a4e80d6a29a3c826d0f3c48#11}'; endif;echo translate_smarty(array('id' => 'fee_paid'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:992640918a4e80d6a29a3c826d0f3c48#11}'; endif;?>
" alt="<?php if ($this->caching && !$this->_cache_including): echo '{nocache:992640918a4e80d6a29a3c826d0f3c48#12}'; endif;echo translate_smarty(array('id' => 'fee_paid'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:992640918a4e80d6a29a3c826d0f3c48#12}'; endif;?>
" />
                        <a href="<?php if ($this->caching && !$this->_cache_including): echo '{nocache:992640918a4e80d6a29a3c826d0f3c48#13}'; endif;echo url_smarty(array('page' => 'event','view' => 'cancelsignup','id' => $this->_tpl_vars['event']->id), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:992640918a4e80d6a29a3c826d0f3c48#13}'; endif;?>
"><?php if ($this->caching && !$this->_cache_including): echo '{nocache:992640918a4e80d6a29a3c826d0f3c48#14}'; endif;echo translate_smarty(array('id' => 'paid'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:992640918a4e80d6a29a3c826d0f3c48#14}'; endif;?>
</a></span>
                    <?php else: ?>
                        <span class="nowrap"><img src="<?php echo $this->_tpl_vars['url_base']; ?>
images/exclamation.png" width="15" title="<?php if ($this->caching && !$this->_cache_including): echo '{nocache:992640918a4e80d6a29a3c826d0f3c48#15}'; endif;echo translate_smarty(array('id' => 'fee_not_paid'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:992640918a4e80d6a29a3c826d0f3c48#15}'; endif;?>
" alt="<?php if ($this->caching && !$this->_cache_including): echo '{nocache:992640918a4e80d6a29a3c826d0f3c48#16}'; endif;echo translate_smarty(array('id' => 'fee_not_paid'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:992640918a4e80d6a29a3c826d0f3c48#16}'; endif;?>
" />
                        <a href="<?php if ($this->caching && !$this->_cache_including): echo '{nocache:992640918a4e80d6a29a3c826d0f3c48#17}'; endif;echo url_smarty(array('page' => 'event','view' => 'payment','id' => $this->_tpl_vars['event']->id), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:992640918a4e80d6a29a3c826d0f3c48#17}'; endif;?>
"><?php if ($this->caching && !$this->_cache_including): echo '{nocache:992640918a4e80d6a29a3c826d0f3c48#18}'; endif;echo translate_smarty(array('id' => 'fee_payment_info'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:992640918a4e80d6a29a3c826d0f3c48#18}'; endif;?>
</a></span>
                    <?php endif; ?>
                <?php else: ?>
                    <span class="nowrap"><img src="<?php echo $this->_tpl_vars['url_base']; ?>
images/infoIcon.png" width="15" title="<?php if ($this->caching && !$this->_cache_including): echo '{nocache:992640918a4e80d6a29a3c826d0f3c48#19}'; endif;echo translate_smarty(array('id' => 'registration_ok'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:992640918a4e80d6a29a3c826d0f3c48#19}'; endif;?>
" alt="<?php if ($this->caching && !$this->_cache_including): echo '{nocache:992640918a4e80d6a29a3c826d0f3c48#20}'; endif;echo translate_smarty(array('id' => 'registration_ok'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:992640918a4e80d6a29a3c826d0f3c48#20}'; endif;?>
" />
                    <a href="<?php if ($this->caching && !$this->_cache_including): echo '{nocache:992640918a4e80d6a29a3c826d0f3c48#21}'; endif;echo url_smarty(array('page' => 'event','view' => 'cancelsignup','id' => $this->_tpl_vars['event']->id), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:992640918a4e80d6a29a3c826d0f3c48#21}'; endif;?>
"><?php if ($this->caching && !$this->_cache_including): echo '{nocache:992640918a4e80d6a29a3c826d0f3c48#22}'; endif;echo translate_smarty(array('id' => 'registration_ok'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:992640918a4e80d6a29a3c826d0f3c48#22}'; endif;?>
</a></span>
                <?php endif; ?>

            <?php endif; ?>


                <?php if ($this->_tpl_vars['loggedon']): ?>
                    <?php if ($this->_tpl_vars['event']->SignupPossible()): ?>
                        <?php if ($this->_tpl_vars['event']->approved !== null): ?>
                                                    <?php elseif ($this->_tpl_vars['user']->role != 'admin' && $this->_tpl_vars['user']->role != 'manager' && $this->_tpl_vars['event']->management != 'td'): ?>
                            <span class="nowrap"><img src="<?php echo $this->_tpl_vars['url_base']; ?>
images/goIcon.png" alt="<?php if ($this->caching && !$this->_cache_including): echo '{nocache:992640918a4e80d6a29a3c826d0f3c48#23}'; endif;echo translate_smarty(array('id' => 'sign_up_here'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:992640918a4e80d6a29a3c826d0f3c48#23}'; endif;?>
" />
                            <a href="<?php if ($this->caching && !$this->_cache_including): echo '{nocache:992640918a4e80d6a29a3c826d0f3c48#24}'; endif;echo url_smarty(array('page' => 'event','view' => 'signupinfo','id' => $this->_tpl_vars['event']->id), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:992640918a4e80d6a29a3c826d0f3c48#24}'; endif;?>
"><?php if ($this->caching && !$this->_cache_including): echo '{nocache:992640918a4e80d6a29a3c826d0f3c48#25}'; endif;echo translate_smarty(array('id' => 'event_signup'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:992640918a4e80d6a29a3c826d0f3c48#25}'; endif;?>
</a></span>
                        <?php endif; ?>
                    <?php endif; ?>


                    <?php if ($this->_tpl_vars['event']->management == 'td' || $this->_tpl_vars['user']->role == 'admin'): ?>
                        <a href="<?php if ($this->caching && !$this->_cache_including): echo '{nocache:992640918a4e80d6a29a3c826d0f3c48#26}'; endif;echo url_smarty(array('page' => 'manageevent','id' => $this->_tpl_vars['event']->id), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:992640918a4e80d6a29a3c826d0f3c48#26}'; endif;?>
"><?php if ($this->caching && !$this->_cache_including): echo '{nocache:992640918a4e80d6a29a3c826d0f3c48#27}'; endif;echo translate_smarty(array('id' => 'event_manage'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:992640918a4e80d6a29a3c826d0f3c48#27}'; endif;?>
</a>
                    <?php endif; ?>
                    <?php if (( $this->_tpl_vars['event']->management != '' || $this->_tpl_vars['user']->role == 'admin' ) && $this->_tpl_vars['event']->EventOngoing()): ?>
                        <a href="<?php if ($this->caching && !$this->_cache_including): echo '{nocache:992640918a4e80d6a29a3c826d0f3c48#28}'; endif;echo url_smarty(array('page' => 'enterresults','id' => $this->_tpl_vars['event']->id), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:992640918a4e80d6a29a3c826d0f3c48#28}'; endif;?>
"><?php if ($this->caching && !$this->_cache_including): echo '{nocache:992640918a4e80d6a29a3c826d0f3c48#29}'; endif;echo translate_smarty(array('id' => 'event_enter_results'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:992640918a4e80d6a29a3c826d0f3c48#29}'; endif;?>
</a>
                    <?php endif; ?>
                    <?php if ($this->_tpl_vars['event']->management == 'official'): ?>
                        <a href="<?php if ($this->caching && !$this->_cache_including): echo '{nocache:992640918a4e80d6a29a3c826d0f3c48#30}'; endif;echo url_smarty(array('page' => 'editnews','id' => $this->_tpl_vars['event']->id), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:992640918a4e80d6a29a3c826d0f3c48#30}'; endif;?>
"><?php if ($this->caching && !$this->_cache_including): echo '{nocache:992640918a4e80d6a29a3c826d0f3c48#31}'; endif;echo translate_smarty(array('id' => 'event_add_news'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:992640918a4e80d6a29a3c826d0f3c48#31}'; endif;?>
</a>
                    <?php endif; ?>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; else: ?>
        <tr><td colspan="4">
            <p><?php if ($this->caching && !$this->_cache_including): echo '{nocache:992640918a4e80d6a29a3c826d0f3c48#32}'; endif;echo translate_smarty(array('id' => 'no_matching_events'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:992640918a4e80d6a29a3c826d0f3c48#32}'; endif;?>
</p>
        </td></tr>
    <?php endif; unset($_from); ?>
</table>

<?php if ($_GET['id'] == '' || $_GET['id'] == 'default'): ?>
    <p><a href="<?php if ($this->caching && !$this->_cache_including): echo '{nocache:992640918a4e80d6a29a3c826d0f3c48#33}'; endif;echo url_smarty(array('page' => 'events','id' => 'currentYear'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:992640918a4e80d6a29a3c826d0f3c48#33}'; endif;?>
"><?php if ($this->caching && !$this->_cache_including): echo '{nocache:992640918a4e80d6a29a3c826d0f3c48#34}'; endif;echo translate_smarty(array('id' => 'all_current_year_events'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:992640918a4e80d6a29a3c826d0f3c48#34}'; endif;?>
</a></p>
<?php endif; ?>

<script type="text/javascript">
//<![CDATA[
<?php echo '
$(document).ready(function(){
    $($(".SortHeading").get(0)).click();
});

'; ?>

//]]>
</script>
<?php endif; ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'include/footer.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>