<?php /* Smarty version 2.6.28, created on 2016-05-21 00:06:07
         compiled from eventviews/leaderboard.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'translate', 'eventviews/leaderboard.tpl', 73, false),array('function', 'math', 'eventviews/leaderboard.tpl', 85, false),array('function', 'counter', 'eventviews/leaderboard.tpl', 91, false),array('modifier', 'escape', 'eventviews/leaderboard.tpl', 88, false),array('modifier', 'lower', 'eventviews/leaderboard.tpl', 131, false),array('modifier', 'replace', 'eventviews/leaderboard.tpl', 131, false),)), $this); ?>
<?php $this->_cache_serials['./Smarty/templates_c\%%86^86F^86F64DE5%%leaderboard.tpl.inc'] = '80cde1efb1e0d95c8645bf833afddc20'; ?> <?php if ($this->_tpl_vars['mode'] == 'head'): ?>

<style type="text/css"><?php echo '
    .resultrow td, .resultrow th {
        border-right: 1px solid black;
        border-bottom: 1px solid black;
        text-align: center;
        margin: 0;
    }

    .results td, .results th {
        background-color: #EEE;
        text-align: center;
        border: 2px solid white;
    }

    .round_selection_table .selected {
        background-color: #DDD;
    }

    .results {
        border-collapse: collapse;
    }

    .rightside {
        text-align: right !important;
    }

    .leftside {
        text-align: left !important;
    }

    .sdtd {
        background-color: white !important;
    }

    .sd {
        background-color: #EEE !important;
        font-weight: bold;
        min-width: 16px;
    }

'; ?>
</style>
<?php else: ?>
 <div id="event_content">
    <?php echo $this->_tpl_vars['page']->formattedText; ?>

</div>

<?php if ($this->_tpl_vars['pdgaUrl']): ?>
<div id="pdga_link">
    <a href="<?php echo $this->_tpl_vars['pdgaUrl']; ?>
"><?php if ($this->caching && !$this->_cache_including): echo '{nocache:80cde1efb1e0d95c8645bf833afddc20#0}'; endif;echo translate_smarty(array('id' => 'event_pdga_results_url'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:80cde1efb1e0d95c8645bf833afddc20#0}'; endif;?>
</a>
</div>
<?php endif; ?>

<?php $this->assign('extrahead', $this->_tpl_vars['xtrahead']); ?>
<p class="preliminary" style="display: none">
    <?php if ($this->caching && !$this->_cache_including): echo '{nocache:80cde1efb1e0d95c8645bf833afddc20#1}'; endif;echo translate_smarty(array('id' => 'preliminary_results'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:80cde1efb1e0d95c8645bf833afddc20#1}'; endif;?>

</p>
<div class="results_raw">
<table class="results">
<?php $_from = $this->_tpl_vars['resultsByClass']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['class'] => $this->_tpl_vars['results']):
?>
    <tr style="border: none">
        <?php echo smarty_function_math(array('assign' => 'colspan','equation' => "5+x",'x' => $this->_tpl_vars['numRounds']), $this);?>

        <td colspan="<?php echo $this->_tpl_vars['colspan']; ?>
" style="background-color: white" class="leftside">
            <a name="c<?php echo $this->_tpl_vars['class']; ?>
"></a>
            <h3><?php echo ((is_array($_tmp=$this->_tpl_vars['class'])) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
</h3>
        </td>
    </tr>
    <?php echo smarty_function_counter(array('assign' => 'rowind','start' => -1), $this);?>

    <?php $_from = $this->_tpl_vars['results']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['result']):
?>
        <?php echo smarty_function_counter(array('assign' => 'rowind'), $this);?>


        <?php if ($this->_tpl_vars['rowind'] == 0): ?>
            <tr>
                <td style="height: 8px; background-color: white;"></td>
            </tr>

            <tr class="thr">
                <th><?php if ($this->caching && !$this->_cache_including): echo '{nocache:80cde1efb1e0d95c8645bf833afddc20#2}'; endif;echo translate_smarty(array('id' => 'result_pos'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:80cde1efb1e0d95c8645bf833afddc20#2}'; endif;?>
</th>
                <th><?php if ($this->caching && !$this->_cache_including): echo '{nocache:80cde1efb1e0d95c8645bf833afddc20#3}'; endif;echo translate_smarty(array('id' => 'result_name'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:80cde1efb1e0d95c8645bf833afddc20#3}'; endif;?>
</th>

                <th><?php if ($this->caching && !$this->_cache_including): echo '{nocache:80cde1efb1e0d95c8645bf833afddc20#4}'; endif;echo translate_smarty(array('id' => 'clubname'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:80cde1efb1e0d95c8645bf833afddc20#4}'; endif;?>
</th>

                <th>PDGA</th>
                <?php if ($this->_tpl_vars['pdga_enabled']): ?>
                <th><?php if ($this->caching && !$this->_cache_including): echo '{nocache:80cde1efb1e0d95c8645bf833afddc20#5}'; endif;echo translate_smarty(array('id' => 'pdga_rating'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:80cde1efb1e0d95c8645bf833afddc20#5}'; endif;?>
</th>
                <?php endif; ?>
                <?php $_from = $this->_tpl_vars['rounds']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['index'] => $this->_tpl_vars['round']):
?>
                    <?php echo smarty_function_math(array('assign' => 'roundNumber','equation' => "x+1",'x' => $this->_tpl_vars['index']), $this);?>

                    <th><?php if ($this->caching && !$this->_cache_including): echo '{nocache:80cde1efb1e0d95c8645bf833afddc20#6}'; endif;echo translate_smarty(array('id' => 'round_number_short','number' => $this->_tpl_vars['roundNumber']), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:80cde1efb1e0d95c8645bf833afddc20#6}'; endif;?>
</th>
              <!--      <th>HCP<?php echo $this->_tpl_vars['roundNumber']; ?>
</th> -->
                <?php endforeach; endif; unset($_from); ?>
                <th><?php if ($this->caching && !$this->_cache_including): echo '{nocache:80cde1efb1e0d95c8645bf833afddc20#7}'; endif;echo translate_smarty(array('id' => 'leaderboard_hole'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:80cde1efb1e0d95c8645bf833afddc20#7}'; endif;?>
</th>
                <th>+/-</th>
                <th><?php if ($this->caching && !$this->_cache_including): echo '{nocache:80cde1efb1e0d95c8645bf833afddc20#8}'; endif;echo translate_smarty(array('id' => 'result_cumulative'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:80cde1efb1e0d95c8645bf833afddc20#8}'; endif;?>
</th>
                <?php if ($this->_tpl_vars['includePoints']): ?>
                <th><?php if ($this->caching && !$this->_cache_including): echo '{nocache:80cde1efb1e0d95c8645bf833afddc20#9}'; endif;echo translate_smarty(array('id' => 'result_tournament'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:80cde1efb1e0d95c8645bf833afddc20#9}'; endif;?>
</th>
                <?php endif; ?>
            </tr>
            <tr>
                <td style="height: 8px; background-color: white;"></td>
            </tr>
        <?php endif; ?>

        <?php $this->assign('country', $this->_tpl_vars['result']['PDGACountry']); ?>
        <?php if (! $this->_tpl_vars['country']): ?><?php $this->assign('country', 'FI'); ?><?php endif; ?>
        <tr class="resultrow">
            <td id="r<?php echo $this->_tpl_vars['result']['PlayerId']; ?>
_pos"><?php echo $this->_tpl_vars['result']['Standing']; ?>
</td>
            <td class="leftside"><span class="flag-icon flag-icon-<?php echo ((is_array($_tmp=$this->_tpl_vars['country'])) ? $this->_run_mod_handler('lower', true, $_tmp) : smarty_modifier_lower($_tmp)); ?>
"></span><?php echo ((is_array($_tmp=((is_array($_tmp=$this->_tpl_vars['result']['FirstName'])) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)))) ? $this->_run_mod_handler('replace', true, $_tmp, ' ', '&nbsp;') : smarty_modifier_replace($_tmp, ' ', '&nbsp;')); ?>
&nbsp;<?php echo ((is_array($_tmp=((is_array($_tmp=$this->_tpl_vars['result']['LastName'])) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)))) ? $this->_run_mod_handler('replace', true, $_tmp, ' ', '&nbsp;') : smarty_modifier_replace($_tmp, ' ', '&nbsp;')); ?>
</td>

            <td><abbr title="<?php echo ((is_array($_tmp=$this->_tpl_vars['result']['ClubLongName'])) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
"><?php echo ((is_array($_tmp=$this->_tpl_vars['result']['ClubName'])) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
</abbr></td>

            <td><?php echo ((is_array($_tmp=$this->_tpl_vars['result']['PDGANumber'])) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
</td>
            <?php if ($this->_tpl_vars['pdga_enabled']): ?>
            <td><?php echo ((is_array($_tmp=$this->_tpl_vars['result']['Rating'])) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
</td>
            <?php endif; ?>

            <?php $_from = $this->_tpl_vars['rounds']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['index'] => $this->_tpl_vars['round']):
?>
                <?php $this->assign('roundid', $this->_tpl_vars['round']->id); ?>
                <?php $this->assign('rresult', $this->_tpl_vars['result']['Results'][$this->_tpl_vars['roundid']]['Total']); ?>
                <?php if (! $this->_tpl_vars['rresult']): ?><?php $this->assign('rresult', 0); ?><?php endif; ?>
                <td id="r<?php echo $this->_tpl_vars['result']['PlayerId']; ?>
_<?php echo $this->_tpl_vars['hr_id']; ?>
"><?php echo $this->_tpl_vars['rresult']; ?>
</td>
             <!--   <td><?php echo $this->_tpl_vars['result']['Results'][$this->_tpl_vars['roundid']]['RoundedHandicap']; ?>
 (<?php echo $this->_tpl_vars['result']['Results'][$this->_tpl_vars['roundid']]['CalculatedHandicap']; ?>
)</td> -->
            <?php endforeach; endif; unset($_from); ?>

            <td id="r<?php echo $this->_tpl_vars['result']['PlayerId']; ?>
_tc"><?php echo $this->_tpl_vars['result']['TotalCompleted']; ?>
</td>

            <td id="r<?php echo $this->_tpl_vars['result']['PlayerId']; ?>
_pm"><?php if ($this->_tpl_vars['result']['DidNotFinish']): ?>DNF<?php else: ?><?php echo $this->_tpl_vars['result']['TotalPlusminus']; ?>
<?php endif; ?></td>
            <td id="r<?php echo $this->_tpl_vars['result']['PlayerId']; ?>
_t"><?php if ($this->_tpl_vars['result']['DidNotFinish']): ?>DNF<?php else: ?><?php echo $this->_tpl_vars['result']['OverallResult']; ?>
<?php endif; ?></td>
            <?php if ($this->_tpl_vars['includePoints']): ?>
            <td id="r<?php echo $this->_tpl_vars['result']['PlayerId']; ?>
_tp">
                <?php $this->assign('tournamentPoints', $this->_tpl_vars['result']['TournamentPoints']); ?>
                <?php if (! $this->_tpl_vars['tournamentPoints']): ?><?php $this->assign('tournamentPoints', 0); ?><?php endif; ?>
                <?php echo smarty_function_math(array('equation' => "x/10",'x' => $this->_tpl_vars['tournamentPoints']), $this);?>

            </td>
            <?php endif; ?>
            <?php if ($this->_tpl_vars['result']['Results'][$this->_tpl_vars['roundid']]['SuddenDeath']): ?>
            <td id="r<?php echo $this->_tpl_vars['result']['PlayerId']; ?>
_p" class="sdtd sd"><?php if ($this->caching && !$this->_cache_including): echo '{nocache:80cde1efb1e0d95c8645bf833afddc20#10}'; endif;echo translate_smarty(array('id' => 'result_sd_panel'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:80cde1efb1e0d95c8645bf833afddc20#10}'; endif;?>
</td>
            <?php endif; ?>
        </tr>
    <?php endforeach; endif; unset($_from); ?>
<?php endforeach; endif; unset($_from); ?>
</table>
</div>
<!-- Jyli Handicap: Show Handicapped results -->
	<?php if ($this->_tpl_vars['event']->levelId == 2): ?>

<br />
<h2><?php if ($this->caching && !$this->_cache_including): echo '{nocache:80cde1efb1e0d95c8645bf833afddc20#11}'; endif;echo translate_smarty(array('id' => 'handicapped_results'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:80cde1efb1e0d95c8645bf833afddc20#11}'; endif;?>
</h2>







<div class="results_hcp">
<table class="results narrow ">
<?php $_from = $this->_tpl_vars['resultsByClassHCP']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['class'] => $this->_tpl_vars['results']):
?>
    <tr style="border: none">
        <?php echo smarty_function_math(array('assign' => 'colspan','equation' => "5+x",'x' => $this->_tpl_vars['numRounds']), $this);?>

        <td colspan="<?php echo $this->_tpl_vars['colspan']; ?>
" style="background-color: white" class="leftside">
            <a name="c<?php echo $this->_tpl_vars['class']; ?>
"></a>
            <h3><?php echo ((is_array($_tmp=$this->_tpl_vars['class'])) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
</h3>
        </td>
    </tr>
    <?php echo smarty_function_counter(array('assign' => 'rowind','start' => -1), $this);?>

    <?php $_from = $this->_tpl_vars['results']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['result']):
?>
        <?php echo smarty_function_counter(array('assign' => 'rowind'), $this);?>


        <?php if ($this->_tpl_vars['rowind'] == 0): ?>
            <tr>
                <td style="height: 8px; background-color: white;"></td>
            </tr>
		
		
		     <tr class="thr">
                <th colspan=4 style="height: 8px; background-color: white;"></th>
                
			<!-- <th><?php if ($this->caching && !$this->_cache_including): echo '{nocache:80cde1efb1e0d95c8645bf833afddc20#12}'; endif;echo translate_smarty(array('id' => 'leaderboard_hole'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:80cde1efb1e0d95c8645bf833afddc20#12}'; endif;?>
</th> -->
                <th colspan=3> &#x25BC;&#8194;&#8194;&#8194; HCP &#8194;&#8194;&#8194;&#x25BC;</th>

            </tr>
			
			
		
		
		
            <tr class="thr">
                <th><?php if ($this->caching && !$this->_cache_including): echo '{nocache:80cde1efb1e0d95c8645bf833afddc20#13}'; endif;echo translate_smarty(array('id' => 'result_pos'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:80cde1efb1e0d95c8645bf833afddc20#13}'; endif;?>
</th>
                <th><?php if ($this->caching && !$this->_cache_including): echo '{nocache:80cde1efb1e0d95c8645bf833afddc20#14}'; endif;echo translate_smarty(array('id' => 'result_name'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:80cde1efb1e0d95c8645bf833afddc20#14}'; endif;?>
</th>
                <?php if ($this->_tpl_vars['sfl_enabled']): ?>
                <th><?php if ($this->caching && !$this->_cache_including): echo '{nocache:80cde1efb1e0d95c8645bf833afddc20#15}'; endif;echo translate_smarty(array('id' => 'clubname'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:80cde1efb1e0d95c8645bf833afddc20#15}'; endif;?>
</th>
                <?php endif; ?>
                <th>PDGA</th>
                <?php if ($this->_tpl_vars['pdga_enabled']): ?>
                <th><?php if ($this->caching && !$this->_cache_including): echo '{nocache:80cde1efb1e0d95c8645bf833afddc20#16}'; endif;echo translate_smarty(array('id' => 'pdga_rating'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:80cde1efb1e0d95c8645bf833afddc20#16}'; endif;?>
</th>
                <?php endif; ?>
                <?php $_from = $this->_tpl_vars['rounds']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['index'] => $this->_tpl_vars['round']):
?>
                    <?php echo smarty_function_math(array('assign' => 'roundNumber','equation' => "x+1",'x' => $this->_tpl_vars['index']), $this);?>

                    <th><?php if ($this->caching && !$this->_cache_including): echo '{nocache:80cde1efb1e0d95c8645bf833afddc20#17}'; endif;echo translate_smarty(array('id' => 'round_number_short','number' => $this->_tpl_vars['roundNumber']), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:80cde1efb1e0d95c8645bf833afddc20#17}'; endif;?>
</th>
                    <th>HCP<?php echo $this->_tpl_vars['roundNumber']; ?>
</th>
                <?php endforeach; endif; unset($_from); ?>
			<!-- <th><?php if ($this->caching && !$this->_cache_including): echo '{nocache:80cde1efb1e0d95c8645bf833afddc20#18}'; endif;echo translate_smarty(array('id' => 'leaderboard_hole'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:80cde1efb1e0d95c8645bf833afddc20#18}'; endif;?>
</th> -->
                <th>+/-</th>
                <th><?php if ($this->caching && !$this->_cache_including): echo '{nocache:80cde1efb1e0d95c8645bf833afddc20#19}'; endif;echo translate_smarty(array('id' => 'result_cumulative'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:80cde1efb1e0d95c8645bf833afddc20#19}'; endif;?>
</th>
                <?php if ($this->_tpl_vars['includePoints']): ?>
                <th><?php if ($this->caching && !$this->_cache_including): echo '{nocache:80cde1efb1e0d95c8645bf833afddc20#20}'; endif;echo translate_smarty(array('id' => 'result_tournament'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:80cde1efb1e0d95c8645bf833afddc20#20}'; endif;?>
</th>
                <?php endif; ?>
            </tr>
            <tr>
                <td style="height: 8px; background-color: white;"></td>
            </tr>
        <?php endif; ?>

        <?php $this->assign('country', $this->_tpl_vars['result']['PDGACountry']); ?>
        <?php if (! $this->_tpl_vars['country']): ?><?php $this->assign('country', 'FI'); ?><?php endif; ?>
        <tr class="resultrow">
            <td id="r<?php echo $this->_tpl_vars['result']['PlayerId']; ?>
_pos"><?php echo $this->_tpl_vars['result']['HCPStanding']; ?>
</td>
            <td class="leftside"><span class="flag-icon flag-icon-<?php echo ((is_array($_tmp=$this->_tpl_vars['country'])) ? $this->_run_mod_handler('lower', true, $_tmp) : smarty_modifier_lower($_tmp)); ?>
"></span><?php echo ((is_array($_tmp=((is_array($_tmp=$this->_tpl_vars['result']['FirstName'])) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)))) ? $this->_run_mod_handler('replace', true, $_tmp, ' ', '&nbsp;') : smarty_modifier_replace($_tmp, ' ', '&nbsp;')); ?>
&nbsp;<?php echo ((is_array($_tmp=((is_array($_tmp=$this->_tpl_vars['result']['LastName'])) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)))) ? $this->_run_mod_handler('replace', true, $_tmp, ' ', '&nbsp;') : smarty_modifier_replace($_tmp, ' ', '&nbsp;')); ?>
</td>
            <?php if ($this->_tpl_vars['sfl_enabled']): ?>
            <td><?php echo ((is_array($_tmp=$this->_tpl_vars['result']['ClubName'])) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
</td>
            <?php endif; ?>
            <td><?php echo ((is_array($_tmp=$this->_tpl_vars['result']['PDGANumber'])) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
</td>
            <?php if ($this->_tpl_vars['pdga_enabled']): ?>
            <td><?php echo ((is_array($_tmp=$this->_tpl_vars['result']['Rating'])) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
</td>
            <?php endif; ?>

            <?php $_from = $this->_tpl_vars['rounds']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['index'] => $this->_tpl_vars['round']):
?>
                <?php $this->assign('roundid', $this->_tpl_vars['round']->id); ?>
                <?php $this->assign('rresult', $this->_tpl_vars['result']['Results'][$this->_tpl_vars['roundid']]['Total']); ?>
                <?php if (! $this->_tpl_vars['rresult']): ?><?php $this->assign('rresult', 0); ?><?php endif; ?>
                <td id="r<?php echo $this->_tpl_vars['result']['PlayerId']; ?>
_<?php echo $this->_tpl_vars['hr_id']; ?>
"><?php echo $this->_tpl_vars['rresult']; ?>
</td>
                <td><?php echo $this->_tpl_vars['result']['Results'][$this->_tpl_vars['roundid']]['RoundedHandicap']; ?>
 (<?php echo $this->_tpl_vars['result']['Results'][$this->_tpl_vars['roundid']]['CalculatedHandicap']; ?>
)</td>
            <?php endforeach; endif; unset($_from); ?>

         <!--   <td id="r<?php echo $this->_tpl_vars['result']['PlayerId']; ?>
_tc"><?php echo $this->_tpl_vars['result']['TotalCompleted']; ?>
</td> -->

            <td id="r<?php echo $this->_tpl_vars['result']['PlayerId']; ?>
_pm"><?php if ($this->_tpl_vars['result']['DidNotFinish']): ?>DNF<?php else: ?><?php echo $this->_tpl_vars['result']['TotalPlusminusHCP']; ?>
<?php endif; ?></td>
            <td id="r<?php echo $this->_tpl_vars['result']['PlayerId']; ?>
_t"><?php if ($this->_tpl_vars['result']['DidNotFinish']): ?>DNF<?php else: ?><?php echo $this->_tpl_vars['result']['HandicappedTotal']; ?>
<?php endif; ?></td>
            <?php if ($this->_tpl_vars['includePoints']): ?>
            <td id="r<?php echo $this->_tpl_vars['result']['PlayerId']; ?>
_tp">
                <?php $this->assign('tournamentPoints', $this->_tpl_vars['result']['TournamentPoints']); ?>
                <?php if (! $this->_tpl_vars['tournamentPoints']): ?><?php $this->assign('tournamentPoints', 0); ?><?php endif; ?>
                <?php echo smarty_function_math(array('equation' => "x/10",'x' => $this->_tpl_vars['tournamentPoints']), $this);?>

            </td>
            <?php endif; ?>
            <?php if ($this->_tpl_vars['result']['Results'][$this->_tpl_vars['roundid']]['SuddenDeath']): ?>
            <td id="r<?php echo $this->_tpl_vars['result']['PlayerId']; ?>
_p" class="sdtd sd"><?php if ($this->caching && !$this->_cache_including): echo '{nocache:80cde1efb1e0d95c8645bf833afddc20#21}'; endif;echo translate_smarty(array('id' => 'result_sd_panel'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:80cde1efb1e0d95c8645bf833afddc20#21}'; endif;?>
</td>
            <?php endif; ?>
        </tr>
    <?php endforeach; endif; unset($_from); ?>
<?php endforeach; endif; unset($_from); ?>
</table>
<div>

<?php endif; ?>
    
<!-- Jyli Handicap end -->
<?php endif; ?>