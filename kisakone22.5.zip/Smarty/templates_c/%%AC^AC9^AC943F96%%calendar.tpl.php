<?php /* Smarty version 2.6.28, created on 2016-05-21 00:23:06
         compiled from include/calendar.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'translate', 'include/calendar.tpl', 29, false),array('modifier', 'replace', 'include/calendar.tpl', 36, false),)), $this); ?>
<?php $this->_cache_serials['./Smarty/templates_c\%%AC^AC9^AC943F96%%calendar.tpl.inc'] = '16f5898342b9842423ee07bf10264fa4'; ?><?php if ($this->_tpl_vars['calendar']): ?>
<?php $this->assign('month', $this->_tpl_vars['calendar']['month']); ?>
<?php ob_start(); ?><?php echo $this->_tpl_vars['calendar']['start']; ?>
<?php if ($this->_tpl_vars['calendar']['end'] != $this->_tpl_vars['calendar']['start']): ?> - <?php echo $this->_tpl_vars['calendar']['end']; ?>
<?php endif; ?><?php $this->_smarty_vars['capture']['default'] = ob_get_contents();  $this->assign('dates', ob_get_contents());ob_end_clean(); ?>

<a href="<?php echo $this->_tpl_vars['calendar']['url']; ?>
" title="<?php echo $this->_tpl_vars['calendar']['title']; ?>
" class="addthisevent">
    <div class="date">
        <span class="mon"><?php if ($this->caching && !$this->_cache_including): echo '{nocache:16f5898342b9842423ee07bf10264fa4#0}'; endif;echo translate_smarty(array('id' => "calendar_month_".($this->_tpl_vars['month'])), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:16f5898342b9842423ee07bf10264fa4#0}'; endif;?>
</span>
        <span class="day"><?php echo $this->_tpl_vars['calendar']['day']; ?>
</span>
        <div class="bdr1"></div>
        <div class="bdr2"></div>
    </div>
    <div class="desc">
        <p>
            <strong class="hed"><?php echo ((is_array($_tmp=$this->_tpl_vars['calendar']['title'])) ? $this->_run_mod_handler('replace', true, $_tmp, ' ', '&nbsp;') : smarty_modifier_replace($_tmp, ' ', '&nbsp;')); ?>
</strong>
            <span class="des"><?php if ($this->caching && !$this->_cache_including): echo '{nocache:16f5898342b9842423ee07bf10264fa4#1}'; endif;echo translate_smarty(array('id' => 'calendar_where'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:16f5898342b9842423ee07bf10264fa4#1}'; endif;?>
: <?php echo ((is_array($_tmp=$this->_tpl_vars['calendar']['location'])) ? $this->_run_mod_handler('replace', true, $_tmp, ' ', '&nbsp;') : smarty_modifier_replace($_tmp, ' ', '&nbsp;')); ?>
<br />
                <?php if ($this->caching && !$this->_cache_including): echo '{nocache:16f5898342b9842423ee07bf10264fa4#2}'; endif;echo translate_smarty(array('id' => 'calendar_when'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:16f5898342b9842423ee07bf10264fa4#2}'; endif;?>
: <?php echo ((is_array($_tmp=$this->_tpl_vars['dates'])) ? $this->_run_mod_handler('replace', true, $_tmp, ' ', '&nbsp;') : smarty_modifier_replace($_tmp, ' ', '&nbsp;')); ?>
</span>
        </p>
    </div>
    <span class="_start"><?php echo $this->_tpl_vars['calendar']['start_data']; ?>
</span>
    <span class="_end"><?php echo $this->_tpl_vars['calendar']['end_data']; ?>
</span>
    <span class="_zonecode">50</span>
    <span class="_summary"><?php echo $this->_tpl_vars['calendar']['title']; ?>
</span>
    <span class="_location"><?php echo $this->_tpl_vars['calendar']['location']; ?>
</span>
    <span class="_organizer"><?php echo $this->_tpl_vars['calendar']['organizer']; ?>
</span>
    <span class="_all_day_event">true</span>
    <span class="_date_format">DD-MM-YYYY</span>
</a>
<?php endif; ?>