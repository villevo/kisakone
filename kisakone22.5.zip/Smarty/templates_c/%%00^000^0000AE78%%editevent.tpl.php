<?php /* Smarty version 2.6.28, created on 2016-05-20 23:48:19
         compiled from editevent.tpl */ ?>
 <?php $this->assign("allowTdChange", IsAdmin()); ?>
 <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'support/eventeditform.tpl', 'smarty_include_vars' => array('new' => false)));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>
