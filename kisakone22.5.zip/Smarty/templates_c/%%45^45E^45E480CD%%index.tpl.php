<?php /* Smarty version 2.6.28, created on 2016-05-20 23:47:20
         compiled from index.tpl */ ?>
<?php require_once(SMARTY_CORE_DIR . 'core.load_plugins.php');
smarty_core_load_plugins(array('plugins' => array(array('function', 'translate', 'index.tpl', 37, false),array('function', 'url', 'index.tpl', 79, false),array('modifier', 'escape', 'index.tpl', 79, false),array('modifier', 'substr', 'index.tpl', 87, false),array('modifier', 'date_format', 'index.tpl', 94, false),)), $this); ?>
<?php $this->_cache_serials['./Smarty/templates_c\%%45^45E^45E480CD%%index.tpl.inc'] = '27e7e07bd3b9d2ec17a9164fc3a44c9b'; ?> <?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'include/header.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>

<?php echo $this->_tpl_vars['content']; ?>


<?php if ($this->_tpl_vars['error']): ?>
    <p class="error"><?php echo $this->_tpl_vars['error']; ?>
</p>

<?php else: ?>
<table>

    <?php $_from = $this->_tpl_vars['lists']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['listtype'] => $this->_tpl_vars['events']):
?>
    <tr><td colspan="7"><h2>
    <?php if ($this->_tpl_vars['listtype'] == 0): ?>
        <?php if ($this->caching && !$this->_cache_including): echo '{nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#0}'; endif;echo translate_smarty(array('id' => 'relevant_events'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#0}'; endif;?>

        <?php $this->assign('trclass', 'hot_event_row'); ?>
    <?php elseif ($this->_tpl_vars['listtype'] == 1): ?>
        <?php if ($this->caching && !$this->_cache_including): echo '{nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#1}'; endif;echo translate_smarty(array('id' => 'registering_events'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#1}'; endif;?>

        <?php $this->assign('trclass', 'event_row'); ?>
    <?php elseif ($this->_tpl_vars['listtype'] == 2): ?>
        <?php if ($this->caching && !$this->_cache_including): echo '{nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#2}'; endif;echo translate_smarty(array('id' => 'registering_soon_events'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#2}'; endif;?>

        <?php $this->assign('trclass', 'event_row'); ?>
    <?php elseif ($this->_tpl_vars['listtype'] == 3): ?>
        <?php if ($this->caching && !$this->_cache_including): echo '{nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#3}'; endif;echo translate_smarty(array('id' => 'upcoming_events'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#3}'; endif;?>

        <?php $this->assign('trclass', 'event_row'); ?>
    <?php elseif ($this->_tpl_vars['listtype'] == 4): ?>
        <?php if ($this->caching && !$this->_cache_including): echo '{nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#4}'; endif;echo translate_smarty(array('id' => 'past_events'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#4}'; endif;?>

        <?php $this->assign('trclass', 'event_row'); ?>
    <?php endif; ?>
    </h2></td></tr>

    <tr>
        <th><?php if ($this->caching && !$this->_cache_including): echo '{nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#5}'; endif;echo translate_smarty(array('id' => 'event_name'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#5}'; endif;?>
</th>
        <th><?php if ($this->caching && !$this->_cache_including): echo '{nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#6}'; endif;echo translate_smarty(array('id' => 'event_location'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#6}'; endif;?>
</th>
        <th><?php if ($this->caching && !$this->_cache_including): echo '{nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#7}'; endif;echo translate_smarty(array('id' => 'event_level'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#7}'; endif;?>
</th>
        <th class="classes_max_width"><?php if ($this->caching && !$this->_cache_including): echo '{nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#8}'; endif;echo translate_smarty(array('id' => 'event_classes'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#8}'; endif;?>
</th>
        <th>
        <?php if ($this->_tpl_vars['listtype'] == 1): ?>
            <?php if ($this->caching && !$this->_cache_including): echo '{nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#9}'; endif;echo translate_smarty(array('id' => 'event_signup_end'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#9}'; endif;?>

        <?php elseif ($this->_tpl_vars['listtype'] == 2): ?>
            <?php if ($this->caching && !$this->_cache_including): echo '{nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#10}'; endif;echo translate_smarty(array('id' => 'event_signup_start'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#10}'; endif;?>

        <?php else: ?>
            <?php if ($this->caching && !$this->_cache_including): echo '{nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#11}'; endif;echo translate_smarty(array('id' => 'event_date'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#11}'; endif;?>

        <?php endif; ?>
        </th>
        <th></th>
        <th></th>
    </tr>
   <?php $_from = $this->_tpl_vars['events']; if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['event']):
?>
        <?php if ($this->_tpl_vars['listtype'] == 1 || $this->_tpl_vars['listtype'] == 2): ?>
            <?php if (! $this->_tpl_vars['event']->isActive): ?>
                <?php continue; ?>
            <?php endif; ?>
        <?php endif; ?>
        <tr class="<?php echo $this->_tpl_vars['trclass']; ?>
">
            <?php if ($this->_tpl_vars['event']->isAccessible()): ?>
            <td><a href="<?php if ($this->caching && !$this->_cache_including): echo '{nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#12}'; endif;echo url_smarty(array('page' => 'event','id' => $this->_tpl_vars['event']->id), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#12}'; endif;?>
"><?php echo ((is_array($_tmp=$this->_tpl_vars['event']->name)) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
</a> </td>
            <?php else: ?>
            <td><?php echo ((is_array($_tmp=$this->_tpl_vars['event']->name)) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
</td>
            <?php endif; ?>
            <td><?php echo ((is_array($_tmp=$this->_tpl_vars['event']->venue)) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
</td>
            <td><?php echo ((is_array($_tmp=$this->_tpl_vars['event']->levelName)) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
</td>
            <td class="classes_max_width">
            <?php $_from = $this->_tpl_vars['event']->GetClasses(); if (!is_array($_from) && !is_object($_from)) { settype($_from, 'array'); }if (count($_from)):
    foreach ($_from as $this->_tpl_vars['class']):
?>
                <?php if ($this->_tpl_vars['class']->short): ?><?php echo ((is_array($_tmp=$this->_tpl_vars['class']->short)) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
<?php else: ?><?php echo ((is_array($_tmp=((is_array($_tmp=$this->_tpl_vars['class']->name)) ? $this->_run_mod_handler('substr', true, $_tmp, 0, 3) : substr($_tmp, 0, 3)))) ? $this->_run_mod_handler('escape', true, $_tmp) : smarty_modifier_escape($_tmp)); ?>
<?php endif; ?>
            <?php endforeach; else: ?>
                -
            <?php endif; unset($_from); ?>
            </td>
            <td>
            <?php if ($this->_tpl_vars['listtype'] == 1): ?>
                <?php echo ((is_array($_tmp=$this->_tpl_vars['event']->signupEnd)) ? $this->_run_mod_handler('date_format', true, $_tmp, "%d.%m.%Y %H:%M") : smarty_modifier_date_format($_tmp, "%d.%m.%Y %H:%M")); ?>

            <?php elseif ($this->_tpl_vars['listtype'] == 2): ?>
                <?php echo ((is_array($_tmp=$this->_tpl_vars['event']->signupStart)) ? $this->_run_mod_handler('date_format', true, $_tmp, "%d.%m.%Y %H:%M") : smarty_modifier_date_format($_tmp, "%d.%m.%Y %H:%M")); ?>

            <?php else: ?>
                <?php echo $this->_tpl_vars['event']->fulldate; ?>

            <?php endif; ?>
            </td>

            <td class="event_links">
            <?php if ($this->_tpl_vars['event']->resultsLocked): ?>
                <span class="nowrap"><img src="<?php echo $this->_tpl_vars['url_base']; ?>
images/trophyIcon.png" alt="<?php if ($this->caching && !$this->_cache_including): echo '{nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#13}'; endif;echo translate_smarty(array('id' => 'results_available'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#13}'; endif;?>
" title="<?php if ($this->caching && !$this->_cache_including): echo '{nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#14}'; endif;echo translate_smarty(array('id' => 'results_available'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#14}'; endif;?>
"/>
                <a href="<?php if ($this->caching && !$this->_cache_including): echo '{nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#15}'; endif;echo url_smarty(array('page' => 'event','view' => 'leaderboard','id' => $this->_tpl_vars['event']->id), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#15}'; endif;?>
"><?php if ($this->caching && !$this->_cache_including): echo '{nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#16}'; endif;echo translate_smarty(array('id' => 'event_results'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#16}'; endif;?>
</a></span>

                <?php if ($this->_tpl_vars['event']->standing != null): ?>
                    <?php if ($this->caching && !$this->_cache_including): echo '{nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#17}'; endif;echo translate_smarty(array('id' => 'your_standing','standing' => $this->_tpl_vars['event']->standing), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#17}'; endif;?>

                <?php endif; ?>
            <?php elseif ($this->_tpl_vars['event']->approved !== null): ?>
                                <?php if ($this->_tpl_vars['event']->paymentEnabled): ?>
                    <?php if ($this->_tpl_vars['event']->eventFeePaid): ?>
                        <span class="nowrap"><img src="<?php echo $this->_tpl_vars['url_base']; ?>
images/thumb_up_green.png" width="15" title="<?php if ($this->caching && !$this->_cache_including): echo '{nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#18}'; endif;echo translate_smarty(array('id' => 'fee_paid'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#18}'; endif;?>
" alt="<?php if ($this->caching && !$this->_cache_including): echo '{nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#19}'; endif;echo translate_smarty(array('id' => 'fee_paid'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#19}'; endif;?>
" />
                        <a href="<?php if ($this->caching && !$this->_cache_including): echo '{nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#20}'; endif;echo url_smarty(array('page' => 'event','view' => 'cancelsignup','id' => $this->_tpl_vars['event']->id), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#20}'; endif;?>
"><?php if ($this->caching && !$this->_cache_including): echo '{nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#21}'; endif;echo translate_smarty(array('id' => 'paid'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#21}'; endif;?>
</a></span>
                    <?php else: ?>
                        <span class="nowrap"><img src="<?php echo $this->_tpl_vars['url_base']; ?>
images/exclamation.png" width="15" title="<?php if ($this->caching && !$this->_cache_including): echo '{nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#22}'; endif;echo translate_smarty(array('id' => 'fee_not_paid'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#22}'; endif;?>
" alt="<?php if ($this->caching && !$this->_cache_including): echo '{nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#23}'; endif;echo translate_smarty(array('id' => 'fee_not_paid'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#23}'; endif;?>
" />
                        <a href="<?php if ($this->caching && !$this->_cache_including): echo '{nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#24}'; endif;echo url_smarty(array('page' => 'event','view' => 'payment','id' => $this->_tpl_vars['event']->id), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#24}'; endif;?>
"><?php if ($this->caching && !$this->_cache_including): echo '{nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#25}'; endif;echo translate_smarty(array('id' => 'fee_payment_info'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#25}'; endif;?>
</a></span>
                    <?php endif; ?>
                <?php else: ?>
                    <span class="nowrap"><img src="<?php echo $this->_tpl_vars['url_base']; ?>
images/infoIcon.png" width="15" title="<?php if ($this->caching && !$this->_cache_including): echo '{nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#26}'; endif;echo translate_smarty(array('id' => 'registration_ok'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#26}'; endif;?>
" alt="<?php if ($this->caching && !$this->_cache_including): echo '{nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#27}'; endif;echo translate_smarty(array('id' => 'registration_ok'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#27}'; endif;?>
" />
                    <a href="<?php if ($this->caching && !$this->_cache_including): echo '{nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#28}'; endif;echo url_smarty(array('page' => 'event','view' => 'cancelsignup','id' => $this->_tpl_vars['event']->id), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#28}'; endif;?>
"><?php if ($this->caching && !$this->_cache_including): echo '{nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#29}'; endif;echo translate_smarty(array('id' => 'registration_ok'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#29}'; endif;?>
</a></span>
                <?php endif; ?>
            <?php endif; ?>

            <?php if ($this->_tpl_vars['loggedon']): ?>
                <?php if ($this->_tpl_vars['event']->SignupPossible()): ?>
                    <?php if ($this->_tpl_vars['event']->approved !== null): ?>
                                            <?php elseif ($this->_tpl_vars['user']->role != 'admin' && $this->_tpl_vars['user']->role != 'manager' && $this->_tpl_vars['event']->management != 'td'): ?>
                        <span class="nowrap"><img src="<?php echo $this->_tpl_vars['url_base']; ?>
images/goIcon.png" alt="<?php if ($this->caching && !$this->_cache_including): echo '{nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#30}'; endif;echo translate_smarty(array('id' => 'sign_up_here'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#30}'; endif;?>
" />
                        <a href="<?php if ($this->caching && !$this->_cache_including): echo '{nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#31}'; endif;echo url_smarty(array('page' => 'event','view' => 'signupinfo','id' => $this->_tpl_vars['event']->id), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#31}'; endif;?>
"><?php if ($this->caching && !$this->_cache_including): echo '{nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#32}'; endif;echo translate_smarty(array('id' => 'event_signup'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#32}'; endif;?>
</a></span>
                    <?php endif; ?>
                <?php endif; ?>


                <?php if ($this->_tpl_vars['event']->management == 'td' || $this->_tpl_vars['user']->role == 'admin'): ?>
                    <a href="<?php if ($this->caching && !$this->_cache_including): echo '{nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#33}'; endif;echo url_smarty(array('page' => 'manageevent','id' => $this->_tpl_vars['event']->id), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#33}'; endif;?>
"><?php if ($this->caching && !$this->_cache_including): echo '{nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#34}'; endif;echo translate_smarty(array('id' => 'event_manage'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#34}'; endif;?>
</a>
                <?php endif; ?>
                <?php if (( $this->_tpl_vars['event']->management != '' || $this->_tpl_vars['user']->role == 'admin' ) && $this->_tpl_vars['event']->EventOngoing()): ?>
                    <a href="<?php if ($this->caching && !$this->_cache_including): echo '{nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#35}'; endif;echo url_smarty(array('page' => 'enterresults','id' => $this->_tpl_vars['event']->id), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#35}'; endif;?>
"><?php if ($this->caching && !$this->_cache_including): echo '{nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#36}'; endif;echo translate_smarty(array('id' => 'event_enter_results'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#36}'; endif;?>
</a>
                <?php endif; ?>
                <?php if ($this->_tpl_vars['event']->management == 'official'): ?>
                    <a href="<?php if ($this->caching && !$this->_cache_including): echo '{nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#37}'; endif;echo url_smarty(array('page' => 'editnews','id' => $this->_tpl_vars['event']->id), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#37}'; endif;?>
"><?php if ($this->caching && !$this->_cache_including): echo '{nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#38}'; endif;echo translate_smarty(array('id' => 'event_add_news'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#38}'; endif;?>
</a>
                <?php endif; ?>
            <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; else: ?>
        <tr><td colspan="7">
            <p><?php if ($this->caching && !$this->_cache_including): echo '{nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#39}'; endif;echo translate_smarty(array('id' => 'no_matching_events'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#39}'; endif;?>
</p>
        </td></tr>
    <?php endif; unset($_from); ?>

    <tr><td colspan="7">
    <?php if ($this->_tpl_vars['listtype'] == 0): ?>
        &nbsp;
    <?php elseif ($this->_tpl_vars['listtype'] == 3): ?>
        <p><a href="<?php if ($this->caching && !$this->_cache_including): echo '{nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#40}'; endif;echo url_smarty(array('page' => 'events','id' => 'upcoming'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#40}'; endif;?>
"><?php if ($this->caching && !$this->_cache_including): echo '{nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#41}'; endif;echo translate_smarty(array('id' => 'show_all'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#41}'; endif;?>
</a></p>
    <?php elseif ($this->_tpl_vars['listtype'] == 4): ?>
        <p><a href="<?php if ($this->caching && !$this->_cache_including): echo '{nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#42}'; endif;echo url_smarty(array('page' => 'eventarchive'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#42}'; endif;?>
"><?php if ($this->caching && !$this->_cache_including): echo '{nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#43}'; endif;echo translate_smarty(array('id' => 'show_archive'), $this);if ($this->caching && !$this->_cache_including): echo '{/nocache:27e7e07bd3b9d2ec17a9164fc3a44c9b#43}'; endif;?>
</a></p>
    <?php endif; ?>
    </td></tr>

    <?php endforeach; endif; unset($_from); ?>
</table>



<?php endif; ?>
<?php $_smarty_tpl_vars = $this->_tpl_vars;
$this->_smarty_include(array('smarty_include_tpl_file' => 'include/footer.tpl', 'smarty_include_vars' => array()));
$this->_tpl_vars = $_smarty_tpl_vars;
unset($_smarty_tpl_vars);
 ?>