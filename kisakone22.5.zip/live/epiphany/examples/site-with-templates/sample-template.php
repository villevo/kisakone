<h1><?php echo $heading; ?></h1>
<p>
  <img src="<?php echo $imageSrc; ?>" align="left" hspace="5" vspace="5"><?php echo $content; ?>
</p>
